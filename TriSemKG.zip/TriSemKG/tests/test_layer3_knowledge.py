import json

import pandas as pd
from rdflib import Graph

from trisemkg.layer2_semantic import Schema
from trisemkg.layer3_knowledge import KnowledgeGraph, query

from .conftest import ROOT


def test_validation_passes(built):
    assert built.validation["passed"]
    assert built.validation["counts"].get("schema_violations", 0) == 0
    assert built.validation["shacl"]["conforms"] is True


def test_all_three_facets_connected(built):
    s = built.stats
    assert {"knowledge", "clinical", "multimedia", "omics"} <= set(s["node_facets"])
    assert s["patients_by_modalities"].get("EHR+multimedia+omics", 0) > 0
    assert s["cross_facet_edges"] > 0


def test_primekg_format(built):
    kg = pd.read_csv(built.output_dir / "kg" / "kg.csv")
    assert list(kg.columns) == ["relation", "display_relation", "x_index", "x_id", "x_type", "x_name", "x_source",
                                "y_index", "y_id", "y_type", "y_name", "y_source"]
    assert len(kg) == 2 * built.stats["edges"]


def test_rdf_and_neo4j_exports(built):
    g = Graph().parse(built.output_dir / "rdf" / "trisemkg.ttl")
    assert len(g) > built.stats["edges"]
    assert (built.output_dir / "neo4j" / "relationships.csv").exists()
    assert (built.output_dir / "neo4j" / "import.sh").read_text().startswith("#!/usr/bin/env bash")


def test_media_features_written(built):
    img = pd.read_csv(built.output_dir / "features" / "media_features_image.csv")
    assert len(img) > 0 and "entropy" in img.columns


def test_save_load_roundtrip(built):
    kg2 = KnowledgeGraph.load(built.output_dir / "kg", Schema.load(ROOT / "schema" / "trisemkg_schema.yaml"))
    assert len(kg2.nodes) == len(built.kg.nodes) and len(kg2.edges) == len(built.kg.edges)


def test_drug_candidates_for_brca_carrier(built, raw_dir):
    truth = pd.read_csv(raw_dir / "cohort_truth.csv").fillna("")
    found = 0
    for r in truth[(truth.brca_carrier != "") & (truth.sample_id != "")].itertuples():
        pid = f"TRISEM:patient-{r.mrn}"
        if query.altered_genes(built.kg, pid):
            df = query.drug_candidates(built.kg, pid)
            found += int("DRUGBANK:DB09074" in set(df.drug_id))
    assert found >= 1


def test_similarity_and_media_queries(built):
    p = built.kg.nodes_of("patient")[0].id
    assert len(query.similar_patients(built.kg, p, 5)) == 5
    assert len(query.media_evidence(built.kg, "MONDO:0007254")) > 0
    assert json.dumps(query.patient_summary(built.kg, p))


def test_owl_generation(tmp_path):
    from trisemkg.layer2_semantic.owl import write_owl
    out = write_owl(ROOT / "schema" / "trisemkg_schema.yaml", tmp_path / "core.ttl")
    assert len(Graph().parse(out)) > 300
