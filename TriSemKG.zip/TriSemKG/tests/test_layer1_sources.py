import pandas as pd

from trisemkg.layer1_sources import build_adapter
from trisemkg.layer1_sources.knowledge import parse_obo


def test_synthetic_files_exist(raw_dir):
    for rel in ("ehr/fhir", "ehr/omop/PERSON.csv", "multimedia/media_manifest.csv", "omics/somatic_variants.vcf",
                "omics/rnaseq_tpm.tsv", "omics/proteomics_log2.tsv", "omics/methylation_beta.tsv", "cohort_truth.csv"):
        assert (raw_dir / rel).exists(), rel


def test_fhir_adapter_extracts_patient_and_codes(raw_dir):
    batches = list(build_adapter({"adapter": "fhir", "path": str(raw_dir / "ehr" / "fhir")}).read())
    assert batches
    b = batches[0]
    patients = [e for e in b.entities.values() if e.entity_type == "patient"]
    assert len(patients) == 1 and patients[0].codes[0].system == "TRISEM-MRN"
    labs = [r for r in b.relations if r.relation == "patient_labtest"]
    assert labs and all("value" in r.attrs for r in labs)


def test_omop_adapter_uses_concept_table(raw_dir):
    b = next(build_adapter({"adapter": "omop", "path": str(raw_dir / "ehr" / "omop")}).read())
    drugs = [e for e in b.entities.values() if e.entity_type == "drug"]
    assert drugs and any(c.system == "RXNORM" for d in drugs for c in d.codes)


def test_media_manifest_checksums(raw_dir):
    b = next(build_adapter({"adapter": "media_manifest", "path": str(raw_dir / "multimedia" / "media_manifest.csv")}).read())
    media = [e for e in b.entities.values() if e.entity_type == "media_object" and "sha256" in e.attrs]
    assert media and all(len(m.attrs["sha256"]) == 64 for m in media)
    assert {r.relation for r in b.relations} >= {"patient_media", "media_anatomy", "media_media"}


def test_vcf_adapter_links_variants_to_genes(raw_dir):
    b = next(build_adapter({"adapter": "vcf", "path": str(raw_dir / "omics" / "somatic_variants.vcf")}).read())
    assert any(r.relation == "variant_protein" for r in b.relations)
    assert all(e.attrs["genome"] == "GRCh38" for e in b.entities.values() if e.entity_type == "variant")


def test_expression_threshold(raw_dir):
    b = next(build_adapter({"adapter": "expression", "path": str(raw_dir / "omics" / "rnaseq_tpm.tsv"),
                            "id_system": "ENSEMBL", "z_threshold": 1.0}).read())
    assert b.relations and all(abs(r.attrs["zscore"]) >= 1.0 for r in b.relations)


def test_obo_parser(tmp_path):
    obo = tmp_path / "mini.obo"
    obo.write_text("format-version: 1.2\n\n[Term]\nid: MONDO:0000001\nname: disease\n\n"
                   "[Term]\nid: MONDO:0007254\nname: breast cancer\nsynonym: \"breast carcinoma\" EXACT []\n"
                   "xref: DOID:1612\nis_a: MONDO:0000001 ! disease\n\n[Term]\nid: MONDO:9999999\nname: old\n"
                   "is_obsolete: true\n")
    terms = parse_obo(obo)
    assert [t["id"] for t in terms] == ["MONDO:0000001", "MONDO:0007254"]
    assert terms[1]["synonyms"] == ["breast carcinoma"] and terms[1]["is_a"] == ["MONDO:0000001"]
    b = next(build_adapter({"adapter": "obo", "path": str(obo), "node_type": "disease", "prefix": "MONDO"}).read())
    assert b.xrefs == [("DOID:1612", "MONDO:0007254", "skos:exactMatch")]
    assert b.relations[0].relation == "disease_disease"


def test_primekg_adapter_dedupes_and_pads(tmp_path):
    cols = ["relation", "display_relation", "x_index", "x_id", "x_type", "x_name", "x_source",
            "y_index", "y_id", "y_type", "y_name", "y_source"]
    rows = [["disease_protein", "associated with", 1, "7254", "disease", "breast cancer", "MONDO", 2, "672", "gene/protein", "BRCA1", "NCBI"],
            ["disease_protein", "associated with", 2, "672", "gene/protein", "BRCA1", "NCBI", 1, "7254", "disease", "breast cancer", "MONDO"],
            ["protein_protein", "ppi", 2, "672", "gene/protein", "BRCA1", "NCBI", 3, "675", "gene/protein", "BRCA2", "NCBI"],
            ["protein_protein", "ppi", 3, "675", "gene/protein", "BRCA2", "NCBI", 2, "672", "gene/protein", "BRCA1", "NCBI"]]
    f = tmp_path / "kg.csv"
    pd.DataFrame(rows, columns=cols).to_csv(f, index=False)
    b = next(build_adapter({"adapter": "primekg", "path": str(f)}).read())
    assert len(b.relations) == 2
    assert "MONDO:0007254" in b.entities and "NCBIGene:672" in b.entities
