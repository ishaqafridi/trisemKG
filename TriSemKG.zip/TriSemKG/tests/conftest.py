from pathlib import Path

import pytest

from trisemkg.config import PipelineConfig
from trisemkg.layer1_sources.synthetic import generate
from trisemkg.pipeline import build

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session")
def raw_dir(tmp_path_factory) -> Path:
    d = tmp_path_factory.mktemp("raw")
    generate(d, n_patients=60, seed=11)
    return d


def make_config(raw: Path, out: Path, **knowledge) -> PipelineConfig:
    cfg = PipelineConfig.load(ROOT / "configs" / "pipeline.yaml", root=ROOT)
    remap = {"data/raw": str(raw)}
    for s in cfg.sources:
        for old, new in remap.items():
            if "path" in s and old in s["path"]:
                s["path"] = new + s["path"].split(old, 1)[1]
    cfg.output_dir = out
    cfg.knowledge.update(knowledge)
    return cfg


@pytest.fixture(scope="session")
def built(raw_dir, tmp_path_factory):
    out = tmp_path_factory.mktemp("out")
    return build(make_config(raw_dir, out))
