from pathlib import Path

import pandas as pd

from trisemkg.layer2_semantic import LabelIndex, MappingStore, OntologyMapper, Schema
from trisemkg.layer2_semantic.curie import to_curie
from trisemkg.model import Code, RawEntity

ROOT = Path(__file__).resolve().parents[1]


def mapper() -> OntologyMapper:
    schema = Schema.load(ROOT / "schema" / "trisemkg_schema.yaml")
    store = MappingStore()
    store.load_dir(ROOT / "mappings")
    idx = LabelIndex()
    idx.add("gene/protein", "NCBIGene:672", "BRCA1", ["BRCA1 DNA repair associated"])
    return OntologyMapper(schema, store, idx)


def test_curie_normalisation():
    assert to_curie(Code("http://hl7.org/fhir/sid/icd-10-cm", "c50911")) == "ICD10CM:C50.911"
    assert to_curie(Code("http://snomed.info/sct", "254837009")) == "SNOMEDCT:254837009"
    assert to_curie(Code("HP", "HP:0000822")) == "HP:0000822"


def test_curated_mapping_snomed_to_mondo():
    r = mapper().map(RawEntity("x", "disease", [Code("http://snomed.info/sct", "254837009")]))
    assert r.object_id == "MONDO:0007254" and r.status == "mapped"


def test_icd_hierarchical_fallback():
    r = mapper().map(RawEntity("x", "disease", [Code("http://hl7.org/fhir/sid/icd-10-cm", "C50.911")]))
    assert r.object_id == "MONDO:0007254" and r.status == "hierarchical" and r.predicate_id == "skos:broadMatch"
    assert r.confidence < 0.9


def test_unmapped_code_is_kept_and_flagged():
    r = mapper().map(RawEntity("x", "disease", [Code("http://hl7.org/fhir/sid/icd-10-cm", "Z80.3")]))
    assert r.object_id == "ICD10CM:Z80.3" and r.status == "unmapped"


def test_lexical_gene_symbol():
    r = mapper().map(RawEntity("x", "gene/protein", [Code("HGNC.SYMBOL", "BRCA1", "BRCA1")], "BRCA1"))
    assert r.object_id == "NCBIGene:672" and r.status == "lexical"


def test_local_identity():
    r = mapper().map(RawEntity("p", "patient", [Code("TRISEM-MRN", "MRN00001")]))
    assert r.object_id == "TRISEM:patient-MRN00001" and r.status == "local"


def test_patients_resolved_across_fhir_and_omop(built, raw_dir):
    truth = pd.read_csv(raw_dir / "cohort_truth.csv")
    assert len(built.kg.nodes_of("patient")) == len(truth)
    both = truth[truth.in_fhir & truth.in_omop].mrn.iloc[0]
    node = built.kg.nodes[f"TRISEM:patient-{both}"]
    assert any(s.startswith("fhir:") for s in node.sources) and any(s.startswith("omop:") for s in node.sources)


def test_phenotype_rules_fire_for_diabetes(built, raw_dir):
    truth = pd.read_csv(raw_dir / "cohort_truth.csv")
    t2d = truth[truth.t2d].mrn
    hits = sum(any(e.y == "HP:0003074" for e in built.kg.out_edges(f"TRISEM:patient-{m}", "patient_phenotype"))
               for m in t2d)
    assert hits >= 0.8 * len(t2d)


def test_mapping_audit_trail(built):
    df = pd.read_csv(built.output_dir / "mapping" / "mappings_applied.sssom.tsv", sep="\t", comment="#")
    assert {"subject_id", "predicate_id", "object_id", "mapping_justification", "confidence", "status"} <= set(df.columns)
    assert (df.status == "hierarchical").any()
