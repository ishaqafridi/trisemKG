"""Build the graph from Python and run the precision-medicine queries.

    python examples/quickstart.py
"""
from pathlib import Path

from trisemkg.config import PipelineConfig
from trisemkg.layer1_sources.synthetic import generate
from trisemkg.layer3_knowledge import query
from trisemkg.pipeline import build
from trisemkg.utils import setup_logging

ROOT = Path(__file__).resolve().parents[1]
setup_logging()
if not (ROOT / "data" / "raw" / "cohort_truth.csv").exists():
    generate(ROOT / "data" / "raw", n_patients=200)

result = build(PipelineConfig.load(ROOT / "configs" / "pipeline.yaml"))
kg = result.kg
print(f"{len(kg.nodes):,} nodes, {len(kg.edges):,} edges; validation passed: {result.validation['passed']}")

# A patient with a tumour sample and a pathogenic BRCA variant
import pandas as pd  # noqa: E402

truth = pd.read_csv(ROOT / "data" / "raw" / "cohort_truth.csv").fillna("")
mrn = truth[(truth.brca_carrier != "") & (truth.sample_id != "")].mrn.iloc[0]
pid = f"TRISEM:patient-{mrn}"
print("\nDrug candidates for", mrn)
print(query.drug_candidates(kg, pid).to_string(index=False))
print("\nMost similar patients")
print(query.similar_patients(kg, pid, 5).to_string(index=False))
print("\nMultimedia evidence for breast cancer (first 5)")
print(query.media_evidence(kg, "MONDO:0007254").head().to_string(index=False))
