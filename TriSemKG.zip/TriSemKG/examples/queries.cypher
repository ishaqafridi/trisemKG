// TriSemKG example Cypher queries (after running output/neo4j/import.sh).

// 1. Drug candidates for a patient: altered gene in a tumour sample is a predictive
//    biomarker of a drug indicated for one of the patient's diagnoses.
MATCH (p:Patient {id: 'TRISEM:patient-MRN00004'})-[:PATIENT_BIOSAMPLE]->(s:Biosample)
      -[bv:BIOSAMPLE_VARIANT]->(v:Variant)-[:VARIANT_PROTEIN]->(g:GeneProtein)
      <-[:DRUG_BIOMARKER]-(d:Drug)-[:INDICATION]->(dx:Disease)<-[:PATIENT_DISEASE]-(p)
RETURN d.name AS drug, g.name AS biomarker, v.name AS variant, dx.name AS indication;

// 2. All multimedia evidence for breast cancer, with modality and patient.
MATCH (m:MediaObject)-[:MEDIA_DISEASE]->(:Disease {id: 'MONDO:0007254'}), (p:Patient)-[:PATIENT_MEDIA]->(m)
RETURN p.id, m.name, m.attributes LIMIT 25;

// 3. Patients with all three data modalities.
MATCH (p:Patient)
WHERE (p)-[:PATIENT_DISEASE]->() AND (p)-[:PATIENT_MEDIA]->() AND (p)-[:PATIENT_BIOSAMPLE]->()
RETURN count(p) AS multimodal_patients;

// 4. Rule-derived phenotypes and the knowledge-level diseases that share them.
MATCH (p:Patient)-[r:PATIENT_PHENOTYPE]->(ph:EffectPhenotype)<-[:DISEASE_PHENOTYPE_POSITIVE]-(dx:Disease)
WHERE r.justification = 'trisem:RuleDerived' AND NOT (p)-[:PATIENT_DISEASE]->(dx)
RETURN p.id, ph.name, dx.name AS candidate_undiagnosed_condition LIMIT 25;

// 5. Histopathology tiles traced back to their slide and patient.
MATCH (t:MediaObject)-[:MEDIA_MEDIA]->(slide:MediaObject)<-[:PATIENT_MEDIA]-(p:Patient)
RETURN p.id, slide.name, collect(t.name) AS tiles LIMIT 10;
