"""Command-line interface: ``trisemkg <command>``."""
from __future__ import annotations

import argparse
import json
import sys

from .utils import setup_logging


def _kg(args):
    from .config import PipelineConfig
    from .layer2_semantic import Schema
    from .layer3_knowledge import KnowledgeGraph
    cfg = PipelineConfig.load(args.config)
    return KnowledgeGraph.load(cfg.output_dir / "kg", Schema.load(cfg.schema))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="trisemkg", description="Three-layer semantic biomedical KG builder")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("synth", help="generate a synthetic multi-modal cohort")
    s.add_argument("--out", default="data/raw")
    s.add_argument("--patients", type=int, default=200)
    s.add_argument("--seed", type=int, default=7)

    b = sub.add_parser("build", help="run Layers 1-3 and write the graph")
    b.add_argument("--config", default="configs/pipeline.yaml")

    d = sub.add_parser("download", help="fetch a public reference source")
    d.add_argument("source")
    d.add_argument("--dest", default="data/external")
    d.add_argument("--force", action="store_true")

    q = sub.add_parser("query", help="run a precision-medicine query on a built graph")
    q.add_argument("kind", choices=["drugs", "similar", "media", "summary"])
    q.add_argument("id", help="patient id (TRISEM:patient-MRN00001 or MRN00001) or disease CURIE")
    q.add_argument("--config", default="configs/pipeline.yaml")
    q.add_argument("-k", type=int, default=10)

    o = sub.add_parser("owl", help="generate the OWL core ontology from the schema")
    o.add_argument("--schema", default="schema/trisemkg_schema.yaml")
    o.add_argument("--out", default="schema/trisemkg_core.owl.ttl")

    st = sub.add_parser("stats", help="print build statistics")
    st.add_argument("--config", default="configs/pipeline.yaml")

    args = ap.parse_args(argv)
    setup_logging(args.verbose)

    if args.cmd == "synth":
        from .layer1_sources.synthetic import generate
        print(json.dumps(generate(args.out, args.patients, args.seed), indent=1))
    elif args.cmd == "build":
        from .config import PipelineConfig
        from .pipeline import build
        r = build(PipelineConfig.load(args.config))
        print((r.output_dir / "stats.md").read_text())
        return 0 if r.validation["passed"] else 1
    elif args.cmd == "download":
        from .layer1_sources.download import download
        print(download(args.source, args.dest, args.force))
    elif args.cmd == "owl":
        from .layer2_semantic.owl import write_owl
        print(write_owl(args.schema, args.out))
    elif args.cmd == "stats":
        from .config import PipelineConfig
        print((PipelineConfig.load(args.config).output_dir / "stats.md").read_text())
    elif args.cmd == "query":
        from .layer3_knowledge import query
        kg = _kg(args)
        ident = args.id if ":" in args.id else f"TRISEM:patient-{args.id}"
        if ident not in kg.nodes:
            print(f"{ident} is not in the graph", file=sys.stderr)
            return 2
        if args.kind == "drugs":
            print(query.drug_candidates(kg, ident).to_string(index=False))
        elif args.kind == "similar":
            print(query.similar_patients(kg, ident, args.k).to_string(index=False))
        elif args.kind == "media":
            print(query.media_evidence(kg, ident).to_string(index=False))
        else:
            print(json.dumps(query.patient_summary(kg, ident), indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
