"""Rule-based semantic enrichment applied after mapping (Layer 2).

Rules turn numeric EHR measurements into ontology-coded phenotypes, e.g.
HbA1c >= 6.5 % -> HP:0003074 Hyperglycemia, giving every patient a phenotype
profile that can be compared with disease-phenotype knowledge.
"""
from __future__ import annotations

import operator
from dataclasses import dataclass
from pathlib import Path

import yaml

OPS = {">=": operator.ge, ">": operator.gt, "<=": operator.le, "<": operator.lt, "==": operator.eq}


@dataclass
class PhenotypeRule:
    id: str
    lab_test: str
    operator: str
    threshold: float
    phenotype: str
    unit: str | None = None

    def fires(self, value: float) -> bool:
        return OPS[self.operator](value, self.threshold)


def load_rules(path: str | Path | None) -> list[PhenotypeRule]:
    if not path or not Path(path).exists():
        return []
    raw = yaml.safe_load(Path(path).read_text()) or {}
    return [PhenotypeRule(**r) for r in raw.get("rules", [])]
