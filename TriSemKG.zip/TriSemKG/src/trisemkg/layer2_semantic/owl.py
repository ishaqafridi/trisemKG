"""Generate the TriSemKG core ontology (OWL 2, Turtle) from the schema YAML.

Each node type becomes an owl:Class under its facet class, aligned to the Biolink
Model with skos:exactMatch; each relation becomes an owl:ObjectProperty with
rdfs:domain and rdfs:range, so the RDF export can be reasoned over and validated.
"""
from __future__ import annotations

from pathlib import Path

from .schema import Schema

BIOLINK = "https://w3id.org/biolink/vocab/"


def _cls(node_type: str) -> str:
    import re
    return "".join(p.capitalize() for p in re.split(r"[/_ -]+", node_type))


def _prop(rel: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9]+", "_", rel).strip("_")


def schema_to_owl(schema: Schema) -> str:
    lines = ["@prefix owl: <http://www.w3.org/2002/07/owl#> .",
             "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
             "@prefix skos: <http://www.w3.org/2004/02/skos/core#> .",
             "@prefix dcterms: <http://purl.org/dc/terms/> .",
             "@prefix tsv: <https://w3id.org/trisemkg/vocab/> .",
             f"@prefix biolink: <{BIOLINK}> .", "",
             "<https://w3id.org/trisemkg/vocab> a owl:Ontology ;",
             '    dcterms:title "TriSemKG core ontology" ;',
             f'    owl:versionInfo "{schema.version}" ;',
             '    rdfs:comment "Generated from schema/trisemkg_schema.yaml. Classes for the knowledge, clinical, '
             'multimedia and omics facets of a precision-medicine knowledge graph." .', ""]
    for facet in sorted({spec["facet"] for spec in schema.node_types.values()}):
        lines += [f"tsv:{facet.capitalize()}Entity a owl:Class ;", f'    rdfs:label "{facet} entity" .', ""]
    for t, spec in schema.node_types.items():
        c = _cls(t)
        lines.append(f"tsv:{c} a owl:Class ;")
        lines.append(f'    rdfs:label "{t}" ;')
        if spec.get("biolink"):
            lines.append(f"    skos:exactMatch biolink:{spec['biolink'].split(':', 1)[1]} ;")
        if spec.get("canonical_prefix"):
            lines.append(f'    tsv:canonicalNamespace "{spec["canonical_prefix"]}" ;')
        lines.append(f"    rdfs:subClassOf tsv:{spec['facet'].capitalize()}Entity .")
        lines.append("")
    for rel, spec in schema.relations.items():
        lines.append(f"tsv:{_prop(rel)} a owl:ObjectProperty{', owl:SymmetricProperty' if spec.get('symmetric') else ''} ;")
        lines.append(f'    rdfs:label "{spec["display"]}" ;')
        lines.append(f'    skos:notation "{rel}" ;')
        lines.append(f"    rdfs:domain tsv:{_cls(spec['domain'])} ;")
        lines.append(f"    rdfs:range tsv:{_cls(spec['range'])} .")
        lines.append("")
    for p, label in (("confidence", "mapping/assertion confidence"), ("justification", "mapping justification"),
                     ("facet", "facet"), ("mappingStatus", "mapping status"), ("uri", "content location"),
                     ("mime_type", "MIME type"), ("modality", "acquisition modality"), ("sha256", "SHA-256 checksum")):
        lines += [f"tsv:{p} a owl:DatatypeProperty ;", f'    rdfs:label "{label}" .', ""]
    return "\n".join(lines)


def write_owl(schema_path: str | Path, out: str | Path) -> Path:
    out = Path(out)
    out.write_text(schema_to_owl(Schema.load(schema_path)))
    return out
