"""Layer 2 orchestration: map entities, resolve duplicates, translate relations,
apply rules and keep a full mapping audit trail."""
from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field
from statistics import mean

from ..model import Edge, MappingResult, Node, SourceBatch
from ..utils import LOG
from .mapper import LabelIndex, OntologyMapper
from .rules import PhenotypeRule
from .schema import Schema
from .sssom import Mapping, MappingStore


@dataclass
class IntegrationResult:
    nodes: dict[str, Node]
    edges: dict[tuple[str, str, str], Edge]
    mapping_log: list[dict] = field(default_factory=list)
    rejected: list[dict] = field(default_factory=list)


def build_label_index(batches: Iterable[SourceBatch], schema: Schema) -> tuple[LabelIndex, set[str]]:
    idx, known = LabelIndex(), set()
    for b in batches:
        if not b.is_knowledge:
            continue
        for e in b.entities.values():
            for c in e.codes:
                curie = f"{c.system}:{c.code}"
                if curie.split(":", 1)[0] == schema.canonical_prefix(e.entity_type):
                    idx.add(e.entity_type, curie, e.name, e.attrs.get("synonyms"))
                    known.add(curie)
    return idx, known


class SemanticIntegrator:
    def __init__(self, schema: Schema, store: MappingStore, rules: list[PhenotypeRule] | None = None,
                 *, lexical: bool = True, icd_fallback: bool = True, min_confidence: float = 0.5) -> None:
        self.schema, self.store, self.rules = schema, store, rules or []
        self.lexical, self.icd_fallback, self.min_confidence = lexical, icd_fallback, min_confidence

    def integrate(self, batches: list[SourceBatch]) -> IntegrationResult:
        for b in batches:  # ontology xrefs become additional mappings
            for subj, obj, pred in b.xrefs:
                self.store.add(Mapping(subj, obj, pred, "semapv:DatabaseCrossReference", 0.9, b.source))
        index, known = build_label_index(batches, self.schema)
        mapper = OntologyMapper(self.schema, self.store, index, lexical=self.lexical,
                                icd_fallback=self.icd_fallback, known=known)
        res = IntegrationResult({}, {})
        cache: dict[tuple, MappingResult] = {}
        for b in sorted(batches, key=lambda x: not x.is_knowledge):  # knowledge first: labels win
            local: dict[str, str] = {}
            for e in b.entities.values():
                key = (e.entity_type, tuple(sorted((c.system, c.code) for c in e.codes)), e.name)
                mr = cache.get(key) or mapper.map(e)
                cache[key] = mr
                local[e.local_id] = mr.object_id
                self._merge_node(res, e, mr, b.source, index)
                res.mapping_log.append({"source": b.source, "entity_type": e.entity_type,
                                        "subject_id": mr.subject_id, "subject_label": e.name or "",
                                        "predicate_id": mr.predicate_id, "object_id": mr.object_id,
                                        "mapping_justification": mr.justification,
                                        "confidence": mr.confidence, "status": mr.status})
            for r in b.relations:
                x, y = local[r.subject], local[r.object]
                xt, yt = res.nodes[x].type, res.nodes[y].type
                err = self.schema.check_edge(r.relation, xt, yt)
                if err:
                    res.rejected.append({"source": b.source, "relation": r.relation, "x": x, "y": y, "error": err})
                    continue
                conf = min(res.nodes[x].confidence, res.nodes[y].confidence)
                self._merge_edge(res, Edge(r.relation, x, y, {b.source}, dict(r.attrs), conf))
        self._apply_rules(res)
        self._summarise_measurements(res)
        st = Counter(m["status"] for m in res.mapping_log)
        LOG.info("Layer 2: %d nodes, %d edges, mapping status %s, %d rejected edges",
                 len(res.nodes), len(res.edges), dict(st), len(res.rejected))
        return res

    def _merge_node(self, res: IntegrationResult, e, mr: MappingResult, source: str, index: LabelIndex) -> None:
        nid = mr.object_id
        n = res.nodes.get(nid)
        if n is None:
            name = index.labels.get(nid) or e.name or nid
            n = Node(nid, e.entity_type, name, self.schema.facet(e.entity_type), mapping_status=mr.status,
                     confidence=mr.confidence)
            res.nodes[nid] = n
        elif n.type != e.entity_type:
            LOG.warning("type clash for %s: %s vs %s (kept %s)", nid, n.type, e.entity_type, n.type)
        n.sources.add(source)
        n.xrefs.update(c for c in (f"{c.system}:{c.code}" for c in e.codes) if c != nid)
        if mr.subject_id != nid:
            n.xrefs.add(mr.subject_id)
        for k, v in e.attrs.items():
            if k == "synonyms":
                continue
            n.attrs.setdefault(k, v)
        if mr.confidence > n.confidence:
            n.confidence, n.mapping_status = mr.confidence, mr.status

    @staticmethod
    def _merge_edge(res: IntegrationResult, e: Edge) -> None:
        old = res.edges.get(e.key)
        if old is None:
            if "value" in e.attrs:
                e.attrs["values"] = [e.attrs.pop("value")]
            res.edges[e.key] = e
            return
        old.sources |= e.sources
        old.confidence = max(old.confidence, e.confidence)
        if "value" in e.attrs:
            old.attrs.setdefault("values", []).append(e.attrs.pop("value"))
        for k, v in e.attrs.items():
            old.attrs.setdefault(k, v)

    def _apply_rules(self, res: IntegrationResult) -> None:
        by_lab = {}
        for r in self.rules:
            by_lab.setdefault(r.lab_test, []).append(r)
        added = 0
        for e in list(res.edges.values()):
            if e.relation != "patient_labtest" or e.y not in by_lab:
                continue
            for rule in by_lab[e.y]:
                vals = [v for v in e.attrs.get("values", []) if v is not None]
                if not vals or not rule.fires(mean(vals)):
                    continue
                if rule.phenotype not in res.nodes:
                    res.nodes[rule.phenotype] = Node(rule.phenotype, "effect/phenotype", rule.phenotype,
                                                     "knowledge", {"rule"}, mapping_status="canonical")
                edge = Edge("patient_phenotype", e.x, rule.phenotype, {f"rule:{rule.id}"},
                            {"rule": rule.id, "derived_from": e.y}, 0.9, "trisem:RuleDerived")
                self._merge_edge(res, edge)
                added += 1
        if added:
            LOG.info("Layer 2: %d phenotype edges derived by %d rules", added, len(self.rules))

    @staticmethod
    def _summarise_measurements(res: IntegrationResult) -> None:
        for e in res.edges.values():
            vals = [v for v in e.attrs.get("values", []) if isinstance(v, (int, float))]
            if vals:
                e.attrs.update(n_obs=len(vals), value_mean=round(mean(vals), 3), value_last=vals[-1],
                               value_min=min(vals), value_max=max(vals))
            e.attrs.pop("values", None)
