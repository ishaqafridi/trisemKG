"""Loading of SSSOM mapping sets (https://w3id.org/sssom) into a lookup store."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

PREDICATE_WEIGHT = {"skos:exactMatch": 1.0, "owl:equivalentClass": 1.0, "skos:closeMatch": 0.9,
                    "skos:broadMatch": 0.85, "skos:narrowMatch": 0.8, "skos:relatedMatch": 0.5}


@dataclass(frozen=True)
class Mapping:
    subject_id: str
    object_id: str
    predicate_id: str
    justification: str
    confidence: float
    mapping_set: str


class MappingStore:
    def __init__(self) -> None:
        self._by_subject: dict[str, list[Mapping]] = defaultdict(list)

    def __len__(self) -> int:
        return sum(len(v) for v in self._by_subject.values())

    def add(self, m: Mapping) -> None:
        self._by_subject[m.subject_id].append(m)

    def load_sssom(self, path: str | Path) -> int:
        path = Path(path)
        df = pd.read_csv(path, sep="\t", comment="#", dtype=str).fillna("")
        n = 0
        for r in df.to_dict("records"):
            if r.get("predicate_id") not in PREDICATE_WEIGHT:
                continue
            conf = float(r["confidence"]) if r.get("confidence") else PREDICATE_WEIGHT[r["predicate_id"]]
            self.add(Mapping(r["subject_id"], r["object_id"], r["predicate_id"],
                             r.get("mapping_justification") or "semapv:UnspecifiedMatching", conf, path.name))
            n += 1
        return n

    def load_dir(self, directory: str | Path) -> int:
        return sum(self.load_sssom(p) for p in sorted(Path(directory).glob("*.sssom.tsv")))

    def lookup(self, subject_id: str, target_prefix: str | None = None) -> list[Mapping]:
        hits = self._by_subject.get(subject_id, [])
        if target_prefix:
            hits = [m for m in hits if m.object_id.split(":", 1)[0] == target_prefix]
        return sorted(hits, key=lambda m: -m.confidence * PREDICATE_WEIGHT.get(m.predicate_id, 0.5))
