"""Schema access: node types, relation domain/range and identifier policy."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass
class Schema:
    prefixes: dict[str, str]
    node_types: dict[str, dict[str, Any]]
    relations: dict[str, dict[str, Any]]
    version: str

    @classmethod
    def load(cls, path: str | Path) -> Schema:
        raw = yaml.safe_load(Path(path).read_text())
        return cls(raw["prefixes"], raw["node_types"], raw["relations"], str(raw.get("version", "")))

    def facet(self, node_type: str) -> str:
        return self.node_types[node_type]["facet"]

    def is_local(self, node_type: str) -> bool:
        return self.node_types[node_type].get("identity") == "local"

    def canonical_prefix(self, node_type: str) -> str | None:
        return self.node_types[node_type].get("canonical_prefix")

    def accepted_prefixes(self, node_type: str) -> list[str]:
        return self.node_types[node_type].get("accepted_prefixes", [])

    def check_edge(self, relation: str, x_type: str, y_type: str) -> str | None:
        """Return an error message when the edge violates the schema, else None."""
        spec = self.relations.get(relation)
        if spec is None:
            return f"unknown relation '{relation}'"
        if (x_type, y_type) != (spec["domain"], spec["range"]):
            return f"{relation} expects {spec['domain']} -> {spec['range']}, got {x_type} -> {y_type}"
        return None

    def expand(self, curie: str) -> str:
        """CURIE -> IRI using the schema prefix map (unknown prefixes get a TriSemKG IRI)."""
        prefix, local = curie.split(":", 1)
        base = self.prefixes.get(prefix, f"https://w3id.org/trisemkg/unknown/{prefix}/")
        return base + local
