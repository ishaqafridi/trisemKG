"""Ontology mapping: from source codes to one canonical identifier per entity.

Strategy, tried in order for an entity of a given node type:

1. local identity      patients, encounters, studies, media, samples and variants get a
                       minted TRISEM identifier from their designated identifier code;
2. canonical code      a code already in the type's canonical namespace is used directly;
3. curated mapping     SSSOM mapping sets and ontology cross-references;
4. hierarchical        ICD-10-CM codes are truncated (C50.911 -> C50.91 -> C50.9 -> C50)
                       until a mapping is found, recorded as a broader match;
5. lexical             normalised labels and synonyms of the canonical ontology;
6. unmapped            the best accepted source code is kept and flagged.
"""
from __future__ import annotations

from collections import defaultdict

from ..model import MappingResult, RawEntity
from ..utils import norm_label, slug
from .curie import to_curie
from .schema import Schema
from .sssom import Mapping, MappingStore

TYPE_SLUG = {"patient": "patient", "encounter": "encounter", "imaging_study": "study", "media_object": "media",
             "biosample": "sample", "variant": "variant"}


class LabelIndex:
    """Normalised label/synonym -> canonical CURIEs, per node type."""

    def __init__(self) -> None:
        self._idx: dict[tuple[str, str], set[str]] = defaultdict(set)
        self.labels: dict[str, str] = {}

    def add(self, node_type: str, curie: str, label: str | None, synonyms: list[str] | None = None) -> None:
        if label:
            self.labels.setdefault(curie, label)
        for text in [label, *(synonyms or [])]:
            if text:
                self._idx[(node_type, norm_label(text))].add(curie)

    def find(self, node_type: str, text: str) -> set[str]:
        return self._idx.get((node_type, norm_label(text)), set())


class OntologyMapper:
    def __init__(self, schema: Schema, store: MappingStore, index: LabelIndex, *, lexical: bool = True,
                 icd_fallback: bool = True, known: set[str] | None = None) -> None:
        self.schema, self.store, self.index = schema, store, index
        self.lexical, self.icd_fallback = lexical, icd_fallback
        self.known = known or set()  # canonical identifiers present in the knowledge facet

    def map(self, e: RawEntity) -> MappingResult:
        t = e.entity_type
        if t not in self.schema.node_types:
            raise KeyError(f"entity type '{t}' is not in the schema")
        curies = [to_curie(c) for c in e.codes]
        if self.schema.is_local(t):
            system = self.schema.node_types[t]["id_system"]
            value = next((c.code for c in e.codes if c.system.upper() == system), None) or e.local_id
            cid = f"TRISEM:{TYPE_SLUG[t]}-{slug(value)}"
            return MappingResult(curies[0] if curies else e.local_id, cid, "skos:exactMatch",
                                 "trisem:LocalIdentifier", 1.0, "local")
        target = self.schema.canonical_prefix(t)
        for c in curies:  # 2. canonical
            if c.split(":", 1)[0] == target:
                return MappingResult(c, c, "skos:exactMatch", "trisem:CanonicalIdentifier", 1.0, "canonical")
        best: tuple[str, Mapping] | None = None
        for c in curies:  # 3. curated / xref
            hits = self.store.lookup(c, target)
            if hits and (best is None or hits[0].confidence > best[1].confidence):
                best = (c, hits[0])
        if best:
            src, m = best
            return MappingResult(src, m.object_id, m.predicate_id, m.justification, m.confidence, "mapped")
        if self.icd_fallback:  # 4. hierarchical
            for c in curies:
                if c.startswith("ICD10CM:"):
                    code = c.split(":", 1)[1]
                    while len(code) > 3:
                        code = code[:-1].rstrip(".")
                        hits = self.store.lookup(f"ICD10CM:{code}", target)
                        if hits:
                            m = hits[0]
                            return MappingResult(c, m.object_id, "skos:broadMatch",
                                                 "trisem:HierarchicalCodeFallback", round(m.confidence * 0.85, 3),
                                                 "hierarchical")
        if self.lexical:  # 5. lexical
            texts = [e.name] + [c.display for c in e.codes] + [c.code for c in e.codes if c.system == "HGNC.SYMBOL"]
            for text in filter(None, texts):
                hits = {h for h in self.index.find(t, text) if h.startswith(target + ":")}
                if len(hits) == 1:
                    return MappingResult(curies[0] if curies else text, hits.pop(), "skos:exactMatch",
                                         "semapv:LexicalMatching", 0.75, "lexical")
        accepted = [c for c in curies if c.split(":", 1)[0] in self.schema.accepted_prefixes(t)] or curies
        keep = accepted[0] if accepted else f"TRISEM:unmapped-{slug(e.local_id)}"
        return MappingResult(keep, keep, "skos:exactMatch", "trisem:Unmapped", 0.5, "unmapped")
