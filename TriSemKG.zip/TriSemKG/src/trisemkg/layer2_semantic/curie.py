"""Normalisation of source code systems into CURIE prefixes."""
from __future__ import annotations

from ..model import Code

# Source code-system identifiers (FHIR URIs, OMOP vocabulary ids, common aliases) -> CURIE prefix
SYSTEM_TO_PREFIX = {
    "http://hl7.org/fhir/sid/icd-10-cm": "ICD10CM", "http://hl7.org/fhir/sid/icd-10": "ICD10CM",
    "icd10cm": "ICD10CM", "icd-10-cm": "ICD10CM", "icd10": "ICD10CM",
    "http://snomed.info/sct": "SNOMEDCT", "snomedct": "SNOMEDCT", "snomed": "SNOMEDCT", "sct": "SNOMEDCT",
    "http://loinc.org": "LOINC", "loinc": "LOINC",
    "http://www.nlm.nih.gov/research/umls/rxnorm": "RXNORM", "rxnorm": "RXNORM",
    "hgnc": "HGNC", "hgnc.symbol": "HGNC.SYMBOL", "ensembl": "ENSEMBL", "uniprot": "UniProtKB",
    "uniprotkb": "UniProtKB", "ncbigene": "NCBIGene", "entrez": "NCBIGene", "drugbank": "DRUGBANK",
    "mondo": "MONDO", "hp": "HP", "hpo": "HP", "go": "GO", "uberon": "UBERON", "doid": "DOID", "chebi": "CHEBI",
    "mesh": "MESH", "react": "REACT", "reactome": "REACT", "dbsnp": "DBSNP", "bodypart": "BODYPART",
    "http://dicom.nema.org/resources/ontology/dcm": "DCM", "dcm": "DCM",
    "trisem-mrn": "TRISEM-MRN", "trisem-enc": "TRISEM-ENC", "trisem-media": "TRISEM-MEDIA",
    "trisem-sample": "TRISEM-SAMPLE", "trisem-var": "TRISEM-VAR", "dicom-uid": "DICOM-UID",
}


def prefix_for(system: str) -> str:
    return SYSTEM_TO_PREFIX.get(system.lower().rstrip("/"), system)


def to_curie(code: Code) -> str:
    prefix = prefix_for(code.system)
    value = code.code.strip()
    if ":" in value and value.split(":", 1)[0].upper() == prefix.upper():
        value = value.split(":", 1)[1]
    if prefix in ("ICD10CM",):
        value = value.upper()
        if len(value) > 3 and "." not in value:  # C50911 -> C50.911
            value = value[:3] + "." + value[3:]
    return f"{prefix}:{value}"
