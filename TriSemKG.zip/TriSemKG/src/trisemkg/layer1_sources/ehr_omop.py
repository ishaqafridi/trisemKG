"""OMOP Common Data Model v5.x adapter (CSV exports of the clinical tables)."""
from __future__ import annotations

from collections.abc import Iterator

import pandas as pd

from ..model import Code, SourceBatch
from .base import SourceAdapter, register

VOCAB_TO_SYSTEM = {"ICD10CM": "ICD10CM", "ICD10": "ICD10CM", "SNOMED": "SNOMEDCT", "RxNorm": "RXNORM",
                   "LOINC": "LOINC", "HCPCS": "HCPCS", "CPT4": "CPT4"}

TABLES = {
    # table: (concept column, source value column, entity type, relation, date column, default vocabulary)
    "CONDITION_OCCURRENCE": ("condition_concept_id", "condition_source_value", "disease", "patient_disease",
                             "condition_start_date", "ICD10CM"),
    "DRUG_EXPOSURE": ("drug_concept_id", "drug_source_value", "drug", "patient_drug",
                      "drug_exposure_start_date", "RxNorm"),
    "MEASUREMENT": ("measurement_concept_id", "measurement_source_value", "lab_test", "patient_labtest",
                    "measurement_date", "LOINC"),
    "PROCEDURE_OCCURRENCE": ("procedure_concept_id", "procedure_source_value", "procedure", "patient_procedure",
                             "procedure_date", "SNOMED"),
}


@register("omop")
class OMOPAdapter(SourceAdapter):
    def _read(self, table: str) -> pd.DataFrame | None:
        for name in (f"{table}.csv", f"{table.lower()}.csv"):
            f = self.path / name
            if f.exists():
                return pd.read_csv(f, dtype=str)
        return None

    def read(self) -> Iterator[SourceBatch]:
        b = self.batch(self.path.name)
        person = self._read("PERSON")
        if person is None:
            return
        concepts: dict[str, tuple[str, str, str]] = {}
        cdf = self._read("CONCEPT")
        if cdf is not None:
            concepts = {r.concept_id: (r.vocabulary_id, r.concept_code, r.concept_name) for r in cdf.itertuples()}
        pid = {}
        for r in person.itertuples():
            mrn = getattr(r, "person_source_value", None) or r.person_id
            pid[r.person_id] = b.entity(f"person:{r.person_id}", "patient", [Code("TRISEM-MRN", mrn)], mrn,
                                        gender={"8507": "male", "8532": "female"}.get(str(r.gender_concept_id)),
                                        birth_year=getattr(r, "year_of_birth", None))
        visits = self._read("VISIT_OCCURRENCE")
        if visits is not None:
            for r in visits.itertuples():
                if r.person_id in pid:
                    e = b.entity(f"visit:{r.visit_occurrence_id}", "encounter",
                                 [Code("TRISEM-ENC", f"omop-{r.visit_occurrence_id}")], "visit",
                                 start=r.visit_start_date)
                    b.relate("patient_encounter", pid[r.person_id], e)
        for table, (ccol, scol, etype, rel, dcol, vocab) in TABLES.items():
            df = self._read(table)
            if df is None:
                continue
            for r in df.to_dict("records"):
                p = pid.get(r["person_id"])
                if p is None:
                    continue
                codes = []
                cid = r.get(ccol)
                if cid in concepts:
                    v, code, cname = concepts[cid]
                    codes.append(Code(VOCAB_TO_SYSTEM.get(v, v), code, cname))
                if isinstance(r.get(scol), str) and r[scol]:
                    codes.append(Code(VOCAB_TO_SYSTEM.get(vocab, vocab), r[scol]))
                if not codes:
                    continue
                lid = f"concept:{etype}:{codes[0].system}|{codes[0].code}"
                b.entity(lid, etype, codes, codes[0].display)
                attrs = {"date": r.get(dcol), "omop_concept_id": cid}
                if table == "MEASUREMENT" and isinstance(r.get("value_as_number"), str):
                    attrs.update(value=float(r["value_as_number"]), unit=r.get("unit_source_value"))
                b.relate(rel, p, lid, **attrs)
        yield b
