"""Reference-knowledge adapters: curated seed tables, OBO ontologies and a PrimeKG backbone."""
from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pandas as pd

from ..model import Code, SourceBatch
from .base import SourceAdapter, register


def _code(curie: str, display: str | None = None) -> Code:
    prefix, local = curie.split(":", 1)
    return Code(prefix, local, display)


@register("seed_knowledge")
class SeedKnowledgeAdapter(SourceAdapter):
    """Directory with nodes.tsv (id, type, name, synonyms) and edges.tsv (relation, x_id, y_id, source)."""

    is_knowledge = True

    def read(self) -> Iterator[SourceBatch]:
        b = self.batch(self.path.name)
        nodes = pd.read_csv(self.path / "nodes.tsv", sep="\t", dtype=str).fillna("")
        types = {}
        for r in nodes.to_dict("records"):
            syn = [s for s in r.get("synonyms", "").split("|") if s]
            b.entity(r["id"], r["type"], [_code(r["id"], r["name"])], r["name"], synonyms=syn or None)
            types[r["id"]] = r["type"]
        edges = pd.read_csv(self.path / "edges.tsv", sep="\t", dtype=str).fillna("")
        for r in edges.to_dict("records"):
            for cid in (r["x_id"], r["y_id"]):
                if cid not in b.entities:
                    raise ValueError(f"seed edge refers to unknown node {cid}")
            b.relate(r["relation"], r["x_id"], r["y_id"], evidence=r.get("source") or None)
        yield b


def parse_obo(path: Path) -> list[dict]:
    """Minimal OBO 1.4 parser: id, name, synonyms, is_a, xrefs, obsolete flag."""
    terms, cur = [], None
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if line.startswith("["):
                if cur:
                    terms.append(cur)
                cur = {"is_a": [], "synonyms": [], "xrefs": []} if line == "[Term]" else None
                continue
            if cur is None or ":" not in line:
                continue
            tag, val = line.split(":", 1)
            val = val.strip()
            if tag == "id":
                cur["id"] = val
            elif tag == "name":
                cur["name"] = val
            elif tag == "is_a":
                cur["is_a"].append(val.split("!")[0].strip())
            elif tag == "synonym" and val.startswith('"'):
                cur["synonyms"].append(val.split('"')[1])
            elif tag == "xref":
                cur["xrefs"].append(val.split(" ")[0])
            elif tag == "is_obsolete" and val == "true":
                cur["obsolete"] = True
    if cur:
        terms.append(cur)
    return [t for t in terms if "id" in t and not t.get("obsolete")]


PARENT_RELATION = {"disease": "disease_disease", "effect/phenotype": "phenotype_phenotype",
                   "biological_process": "bioprocess_bioprocess", "molecular_function": "molfunc_molfunc",
                   "cellular_component": "cellcomp_cellcomp", "anatomy": "anatomy_anatomy"}
XREF_PREFIX = {"ICD10CM": "ICD10CM", "ICD10": "ICD10CM", "SCTID": "SNOMEDCT", "SNOMEDCT_US": "SNOMEDCT",
               "SNOMEDCT_US_2023_03_01": "SNOMEDCT", "DOID": "DOID", "UMLS": "UMLS", "MESH": "MESH",
               "OMIM": "OMIM", "NCIT": "NCIT", "Orphanet": "Orphanet"}


@register("obo")
class OBOAdapter(SourceAdapter):
    """Loads an OBO ontology (MONDO, HPO, GO, UBERON ...). Terms whose prefix matches
    ``prefix`` (default: inferred from file) become nodes of ``node_type``; is_a gives
    parent-child edges; xrefs feed Layer 2 as cross-reference mappings."""

    is_knowledge = True

    def read(self) -> Iterator[SourceBatch]:
        node_type = self.options["node_type"]
        prefix = self.options.get("prefix") or self.path.stem.upper()
        b = self.batch(self.path.name)
        terms = [t for t in parse_obo(self.path) if t["id"].split(":")[0].upper() == prefix.upper()]
        ids = {t["id"] for t in terms}
        rel = PARENT_RELATION.get(node_type)
        for t in terms:
            b.entity(t["id"], node_type, [_code(t["id"], t.get("name"))], t.get("name", t["id"]),
                     synonyms=t["synonyms"] or None)
            for x in t["xrefs"]:
                if ":" in x:
                    p, local = x.split(":", 1)
                    if p in XREF_PREFIX:
                        b.xrefs.append((f"{XREF_PREFIX[p]}:{local}", t["id"], "skos:exactMatch"))
        if rel:
            for t in terms:
                for parent in t["is_a"]:
                    if parent in ids:
                        b.relate(rel, parent, t["id"])
        yield b


PRIMEKG_SOURCE_PREFIX = {"NCBI": ("NCBIGene", 0), "DrugBank": ("DRUGBANK", 0), "MONDO": ("MONDO", 7),
                         "MONDO_grouped": ("MONDO", 7), "HPO": ("HP", 7), "GO": ("GO", 7), "REACTOME": ("REACT", 0),
                         "UBERON": ("UBERON", 7), "CTD": ("MESH", 0)}


@register("primekg")
class PrimeKGAdapter(SourceAdapter):
    """Imports PrimeKG's kg.csv (Chandak et al., Sci Data 2023) as the knowledge backbone.

    PrimeKG lists every undirected edge twice; only the direction matching the TriSemKG
    schema's domain/range (or the lower node index for same-type relations) is kept.
    Grouped MONDO identifiers keep their first member as the identifier.
    """

    is_knowledge = True

    @staticmethod
    def curie(source: str, raw_id: str) -> str:
        prefix, pad = PRIMEKG_SOURCE_PREFIX.get(source, (source.upper(), 0))
        first = str(raw_id).split("_")[0]
        if pad and first.isdigit():
            first = first.zfill(pad)
        return f"{prefix}:{first}"

    def read(self) -> Iterator[SourceBatch]:
        from ..layer2_semantic.schema import Schema  # lazy: Layer 1 reads the schema only for edge direction
        schema = Schema.load(Path(self.options.get("schema", Path(__file__).resolve().parents[3] /
                                                   "schema" / "trisemkg_schema.yaml")))
        b = self.batch(self.path.name)
        chunks = pd.read_csv(self.path, dtype=str, chunksize=500_000, low_memory=False)
        for df in chunks:
            for r in df.itertuples(index=False):
                rel = r.relation
                spec = schema.relations.get(rel)
                if spec is None:
                    continue
                if spec["domain"] == spec["range"]:
                    if int(r.x_index) > int(r.y_index):
                        continue
                elif (r.x_type, r.y_type) != (spec["domain"], spec["range"]):
                    continue
                xs, ys = self.curie(r.x_source, r.x_id), self.curie(r.y_source, r.y_id)
                b.entity(xs, r.x_type, [_code(xs, r.x_name)], r.x_name, primekg_index=int(r.x_index))
                b.entity(ys, r.y_type, [_code(ys, r.y_name)], r.y_name, primekg_index=int(r.y_index))
                b.relate(rel, xs, ys, display_relation=r.display_relation, evidence="PrimeKG")
        yield b
