"""Layer 1 adapter interface and registry.

An adapter reads one kind of source and yields :class:`SourceBatch` objects. It
does no ontology mapping: it only records the codes the source itself carries,
so every mapping decision stays in Layer 2 where it can be audited.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

from ..model import SourceBatch
from ..utils import LOG

REGISTRY: dict[str, type[SourceAdapter]] = {}


def register(name: str) -> Callable[[type[SourceAdapter]], type[SourceAdapter]]:
    def deco(cls: type[SourceAdapter]) -> type[SourceAdapter]:
        cls.name = name
        REGISTRY[name] = cls
        return cls
    return deco


class SourceAdapter(ABC):
    name = "base"
    is_knowledge = False

    def __init__(self, path: str | Path, **options: Any) -> None:
        self.path = Path(path)
        self.options = options

    def available(self) -> bool:
        return self.path.exists()

    @abstractmethod
    def read(self) -> Iterator[SourceBatch]:
        ...

    def batch(self, source: str) -> SourceBatch:
        return SourceBatch(source=f"{self.name}:{source}", adapter=self.name, is_knowledge=self.is_knowledge)


def build_adapter(spec: dict[str, Any]) -> SourceAdapter:
    spec = dict(spec)
    name = spec.pop("adapter")
    spec.pop("enabled", None)
    if name not in REGISTRY:
        raise KeyError(f"Unknown adapter '{name}'. Known: {sorted(REGISTRY)}")
    return REGISTRY[name](**spec)


def load_sources(specs: list[dict[str, Any]]) -> Iterator[SourceBatch]:
    for spec in specs:
        if spec.get("enabled", True) is False:
            LOG.info("Layer 1: skipping disabled source %s (%s)", spec.get("adapter"), spec.get("path"))
            continue
        adapter = build_adapter(spec)
        if not adapter.available():
            LOG.warning("Layer 1: source not found, skipped: %s %s", adapter.name, adapter.path)
            continue
        n = 0
        for batch in adapter.read():
            n += 1
            yield batch
        LOG.info("Layer 1: %-15s %4d batch(es) from %s", adapter.name, n, adapter.path)
