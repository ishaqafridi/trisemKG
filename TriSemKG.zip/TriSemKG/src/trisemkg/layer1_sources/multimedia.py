"""Multimedia object adapters: DICOM files and a generic media manifest.

The manifest covers any media type (whole-slide images and tiles, photographs,
ultrasound cine loops, audio dictations, scanned or text clinical documents).
Each object becomes a ``media_object`` node with its URI, MIME type, modality,
SHA-256 checksum and links to the patient, study, anatomy and diagnosis.
"""
from __future__ import annotations

import mimetypes
from collections.abc import Iterator
from pathlib import Path

import pandas as pd

from ..model import Code, SourceBatch
from ..utils import LOG, sha256_file
from .base import SourceAdapter, register


def _curie_code(value: str) -> Code:
    """Turn 'PREFIX:code' into a Code; plain values become DICOM body-part codes."""
    if ":" in value:
        prefix, code = value.split(":", 1)
        return Code(prefix, code)
    return Code("BODYPART", value.upper())


@register("media_manifest")
class MediaManifestAdapter(SourceAdapter):
    """CSV with columns: media_id, patient_mrn, path, modality, mime_type, study_uid,
    body_site, finding_code, derived_from, acquired, title. Only media_id, patient_mrn
    and path are required."""

    def read(self) -> Iterator[SourceBatch]:
        df = pd.read_csv(self.path, dtype=str).fillna("")
        base = self.path.parent
        b = self.batch(self.path.name)
        for r in df.to_dict("records"):
            f = (base / r["path"]) if not Path(r["path"]).is_absolute() else Path(r["path"])
            mime = r.get("mime_type") or mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            attrs = dict(uri=str(f), mime_type=mime, modality=r.get("modality") or "OT",
                         acquired=r.get("acquired") or None, title=r.get("title") or None)
            if f.exists():
                attrs.update(sha256=sha256_file(f), size_bytes=f.stat().st_size)
            else:
                LOG.warning("media file missing: %s", f)
            m = b.entity(f"media:{r['media_id']}", "media_object", [Code("TRISEM-MEDIA", r["media_id"])],
                         r.get("title") or r["media_id"], **attrs)
            p = b.entity(f"patient:{r['patient_mrn']}", "patient", [Code("TRISEM-MRN", r["patient_mrn"])],
                         r["patient_mrn"])
            b.relate("patient_media", p, m)
            if r.get("study_uid"):
                s = b.entity(f"study:{r['study_uid']}", "imaging_study", [Code("DICOM-UID", r["study_uid"])],
                             f"Study {r['study_uid']}")
                b.relate("media_study", m, s)
                b.relate("patient_study", p, s)
            if r.get("body_site"):
                code = _curie_code(r["body_site"])
                a = b.entity(f"anat:{code.system}|{code.code}", "anatomy", [code], code.code.title())
                b.relate("media_anatomy", m, a)
            if r.get("finding_code"):
                code = _curie_code(r["finding_code"])
                d = b.entity(f"dx:{code.system}|{code.code}", "disease", [code])
                b.relate("media_disease", m, d, label_source="manifest")
            if r.get("derived_from"):
                parent = b.entity(f"media:{r['derived_from']}", "media_object",
                                  [Code("TRISEM-MEDIA", r["derived_from"])], r["derived_from"])
                b.relate("media_media", m, parent)
        yield b


@register("dicom")
class DICOMAdapter(SourceAdapter):
    """Reads DICOM headers (pixels are not loaded) with pydicom."""

    def read(self) -> Iterator[SourceBatch]:
        try:
            import pydicom
        except ImportError:
            LOG.warning("pydicom not installed; DICOM source skipped (pip install trisemkg[dicom])")
            return
        files = [self.path] if self.path.is_file() else sorted(self.path.rglob("*.dcm"))
        b = self.batch(self.path.name)
        for f in files:
            ds = pydicom.dcmread(f, stop_before_pixels=True)
            sop = str(ds.SOPInstanceUID)
            m = b.entity(f"media:{sop}", "media_object", [Code("TRISEM-MEDIA", sop)],
                         str(getattr(ds, "SeriesDescription", "") or f.stem),
                         uri=str(f), mime_type="application/dicom", modality=str(getattr(ds, "Modality", "OT")),
                         sha256=sha256_file(f), size_bytes=f.stat().st_size,
                         acquired=str(getattr(ds, "StudyDate", "")) or None,
                         rows=int(getattr(ds, "Rows", 0)) or None, columns=int(getattr(ds, "Columns", 0)) or None,
                         laterality=str(getattr(ds, "ImageLaterality", "")) or None,
                         view_position=str(getattr(ds, "ViewPosition", "")) or None)
            p = b.entity(f"patient:{ds.PatientID}", "patient", [Code("TRISEM-MRN", str(ds.PatientID))],
                         str(ds.PatientID))
            s = b.entity(f"study:{ds.StudyInstanceUID}", "imaging_study",
                         [Code("DICOM-UID", str(ds.StudyInstanceUID))],
                         str(getattr(ds, "StudyDescription", "")) or f"Study {ds.StudyInstanceUID}",
                         modality=str(getattr(ds, "Modality", "")))
            b.relate("patient_media", p, m)
            b.relate("patient_study", p, s)
            b.relate("media_study", m, s)
            part = str(getattr(ds, "BodyPartExamined", "") or "")
            if part:
                a = b.entity(f"anat:BODYPART|{part}", "anatomy", [Code("BODYPART", part.upper())], part.title())
                b.relate("media_anatomy", m, a)
        yield b
