"""Synthetic multi-modal cohort generator.

Produces a small, fully synthetic but structurally realistic dataset so the whole
pipeline runs without access to protected health information:

* EHR/EMR: FHIR R4 bundles for ~75% of patients and an OMOP CDM extract for the rest,
  with deliberate overlap so Layer 2 must resolve patients across both systems;
* multimedia: DICOM mammograms, histopathology slide thumbnails and derived tiles
  (PNG), ultrasound cine loops (animated GIF), pathology reports (text) and audio
  dictations (WAV);
* multi-omics: a sample sheet, somatic/germline VCF, RNA-seq TPM, proteomics and
  methylation matrices.

No record describes a real person. Variant positions fall inside the GRCh38 gene
spans but are random and must not be interpreted clinically.
"""
from __future__ import annotations

import csv
import json
import math
import wave
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

GENES = {  # symbol: (Ensembl, UniProt, chrom, start, end, base TPM)
    "BRCA1": ("ENSG00000012048", "P38398", "17", 43044295, 43125483, 12),
    "BRCA2": ("ENSG00000139618", "P51587", "13", 32315474, 32400266, 6),
    "TP53": ("ENSG00000141510", "P04637", "17", 7661779, 7687550, 40),
    "ERBB2": ("ENSG00000141736", "P04626", "17", 39687914, 39730426, 30),
    "ESR1": ("ENSG00000091831", "P03372", "6", 151656691, 152129619, 15),
    "PGR": ("ENSG00000082175", "P06401", "11", 101029624, 101129813, 8),
    "PIK3CA": ("ENSG00000121879", "P42336", "3", 179148114, 179240093, 18),
    "PARP1": ("ENSG00000143799", "P09874", "1", 226360210, 226408093, 45),
    "CYP19A1": ("ENSG00000137869", "P11511", "15", 51208057, 51338596, 3),
    "ACE": ("ENSG00000159640", "P12821", "17", 63477061, 63498380, 10),
}
ICD = "http://hl7.org/fhir/sid/icd-10-cm"
SCT = "http://snomed.info/sct"
LNC = "http://loinc.org"
RXN = "http://www.nlm.nih.gov/research/umls/rxnorm"
UCUM = "http://unitsofmeasure.org"
LABS = {  # LOINC: (display, unit)
    "4548-4": ("Hemoglobin A1c/Hemoglobin.total in Blood", "%"),
    "2345-7": ("Glucose [Mass/volume] in Serum or Plasma", "mg/dL"),
    "8480-6": ("Systolic blood pressure", "mm[Hg]"),
    "8462-4": ("Diastolic blood pressure", "mm[Hg]"),
    "39156-5": ("Body mass index (BMI) [Ratio]", "kg/m2"),
    "2160-0": ("Creatinine [Mass/volume] in Serum or Plasma", "mg/dL"),
}
DRUGS = {"tamoxifen": "10324", "letrozole": "72965", "trastuzumab": "224905", "olaparib": "1597582",
         "metformin": "6809", "lisinopril": "29046"}


@dataclass
class Patient:
    idx: int
    mrn: str
    sex: str
    birth_year: int
    breast_cancer: bool
    t2d: bool
    htn: bool
    er_pos: bool = False
    her2_pos: bool = False
    brca_carrier: str | None = None
    family_history: bool = False
    in_fhir: bool = True
    in_omop: bool = False
    study_uid: str | None = None
    sample_id: str | None = None
    drugs: list[str] = field(default_factory=list)


def _uid(rng: np.random.Generator) -> str:
    digits = rng.integers(0, 10, 30)
    digits[0] = rng.integers(1, 10)  # DICOM UID components must not start with 0
    return "1.2.826.0.1.3680043.8.498." + "".join(str(d) for d in digits)


def make_cohort(n: int, rng: np.random.Generator) -> list[Patient]:
    out = []
    for i in range(1, n + 1):
        bc = rng.random() < 0.5
        sex = "female" if (bc and rng.random() < 0.97) or (not bc and rng.random() < 0.5) else "male"
        p = Patient(i, f"MRN{i:05d}", sex, int(rng.integers(1945, 1995)), bc,
                    rng.random() < 0.3, rng.random() < 0.4)
        if bc:
            p.er_pos = rng.random() < 0.7
            p.her2_pos = rng.random() < 0.2
            r = rng.random()
            p.brca_carrier = "BRCA1" if r < 0.08 else "BRCA2" if r < 0.15 else None
            p.family_history = rng.random() < 0.25 or p.brca_carrier is not None
            p.study_uid = _uid(rng)
            if rng.random() < 0.6:
                p.sample_id = f"S{i:05d}-T"
            p.drugs += ["tamoxifen" if rng.random() < 0.5 else "letrozole"] if p.er_pos else []
            p.drugs += ["trastuzumab"] if p.her2_pos else []
            p.drugs += ["olaparib"] if p.brca_carrier and not p.her2_pos else []
        p.drugs += ["metformin"] if p.t2d else []
        p.drugs += ["lisinopril"] if p.htn else []
        p.in_fhir = rng.random() < 0.75
        p.in_omop = (not p.in_fhir) or rng.random() < 0.2
        out.append(p)
    return out


def _labs(p: Patient, rng: np.random.Generator) -> dict[str, float]:
    return {
        "4548-4": rng.normal(7.8, 0.8) if p.t2d else rng.normal(5.4, 0.3),
        "2345-7": rng.normal(160, 25) if p.t2d else rng.normal(92, 9),
        "8480-6": rng.normal(152, 10) if p.htn else rng.normal(121, 9),
        "8462-4": rng.normal(94, 7) if p.htn else rng.normal(78, 6),
        "39156-5": rng.normal(31.5, 4) if p.t2d else rng.normal(25.5, 3.5),
        "2160-0": max(0.4, rng.normal(1.05, 0.25)),
    }


def _conditions(p: Patient, rng: np.random.Generator) -> list[list[tuple[str, str, str]]]:
    conds = []
    if p.breast_cancer:
        icd = rng.choice(["C50.911", "C50.912", "C50.9"])
        c = [(ICD, str(icd), "Malignant neoplasm of breast")]
        if rng.random() < 0.6:
            c.append((SCT, "254837009", "Malignant neoplasm of breast"))
        conds.append(c)
    if p.t2d:
        conds.append([(ICD, "E11.9", "Type 2 diabetes mellitus without complications"),
                      (SCT, "44054006", "Diabetes mellitus type 2")])
    if p.htn:
        conds.append([(ICD, "I10", "Essential (primary) hypertension")])
    if p.family_history:
        conds.append([(ICD, "Z80.3", "Family history of malignant neoplasm of breast")])
    return conds


def write_fhir(cohort: list[Patient], out: Path, rng: np.random.Generator) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for p in (q for q in cohort if q.in_fhir):
        pid = f"pat-{p.mrn}"
        res: list[dict] = [{"resourceType": "Patient", "id": pid, "gender": p.sex,
                            "birthDate": f"{p.birth_year}-0{rng.integers(1, 9)}-1{rng.integers(0, 9)}",
                            "identifier": [{"system": "urn:trisemkg:mrn", "value": p.mrn,
                                            "type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/v2-0203", "code": "MR"}]}}]}]
        ref = {"reference": f"Patient/{pid}"}
        n = 0

        def rid(kind: str, mrn: str = p.mrn) -> str:
            nonlocal n
            n += 1
            return f"{kind[:3].lower()}-{mrn}-{n}"

        encs = []
        for k in range(int(rng.integers(2, 4))):
            eid = rid("Encounter")
            date = f"202{k + 2}-0{rng.integers(1, 9)}-1{rng.integers(0, 9)}"
            encs.append((eid, date))
            res.append({"resourceType": "Encounter", "id": eid, "status": "finished",
                        "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode", "code": "AMB"},
                        "subject": ref, "period": {"start": date}})
        for codings in _conditions(p, rng):
            res.append({"resourceType": "Condition", "id": rid("Condition"), "subject": ref,
                        "encounter": {"reference": f"Encounter/{encs[0][0]}"}, "onsetDateTime": encs[0][1],
                        "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-clinical", "code": "active"}]},
                        "code": {"coding": [{"system": s, "code": c, "display": d} for s, c, d in codings],
                                 "text": codings[0][2]}})
        for d in p.drugs:
            res.append({"resourceType": "MedicationRequest", "id": rid("MedicationRequest"), "status": "active",
                        "intent": "order", "subject": ref, "authoredOn": encs[0][1],
                        "medicationCodeableConcept": {"coding": [{"system": RXN, "code": DRUGS[d], "display": d}]}})
        for eid, date in encs:
            for code, value in _labs(p, rng).items():
                disp, unit = LABS[code]
                res.append({"resourceType": "Observation", "id": rid("Observation"), "status": "final",
                            "subject": ref, "encounter": {"reference": f"Encounter/{eid}"},
                            "effectiveDateTime": date,
                            "code": {"coding": [{"system": LNC, "code": code, "display": disp}]},
                            "valueQuantity": {"value": round(float(value), 2), "unit": unit, "system": UCUM,
                                              "code": unit}})
        if p.breast_cancer:
            res.append({"resourceType": "Procedure", "id": rid("Procedure"), "status": "completed",
                        "subject": ref, "performedDateTime": encs[0][1],
                        "code": {"coding": [{"system": SCT, "code": "71651007", "display": "Mammography"}]}})
            res.append({"resourceType": "ImagingStudy", "id": rid("ImagingStudy"), "status": "available",
                        "subject": ref, "started": encs[0][1], "description": "Bilateral mammography",
                        "identifier": [{"system": "urn:dicom:uid", "value": f"urn:oid:{p.study_uid}"}],
                        "modality": [{"system": "http://dicom.nema.org/resources/ontology/DCM", "code": "MG"}]})
        bundle = {"resourceType": "Bundle", "type": "collection",
                  "entry": [{"fullUrl": f"urn:uuid:{r['id']}", "resource": r} for r in res]}
        (out / f"bundle_{p.mrn}.json").write_text(json.dumps(bundle, indent=1))


def write_omop(cohort: list[Patient], out: Path, rng: np.random.Generator) -> None:
    out.mkdir(parents=True, exist_ok=True)
    concepts: dict[tuple[str, str], tuple[int, str]] = {}

    def concept(vocab: str, code: str, name: str) -> int:
        if (vocab, code) not in concepts:
            concepts[(vocab, code)] = (2_000_000_001 + len(concepts), name)
        return concepts[(vocab, code)][0]

    rows: dict[str, list[dict]] = {k: [] for k in ("PERSON", "VISIT_OCCURRENCE", "CONDITION_OCCURRENCE",
                                                    "DRUG_EXPOSURE", "MEASUREMENT")}
    cid = did = mid = 0
    for vid, p in enumerate((q for q in cohort if q.in_omop), start=1):
        rows["PERSON"].append({"person_id": p.idx, "gender_concept_id": 8532 if p.sex == "female" else 8507,
                               "year_of_birth": p.birth_year, "person_source_value": p.mrn})
        date = f"2023-0{rng.integers(1, 9)}-0{rng.integers(1, 9)}"
        rows["VISIT_OCCURRENCE"].append({"visit_occurrence_id": vid, "person_id": p.idx, "visit_concept_id": 9202,
                                         "visit_start_date": date})
        for codings in _conditions(p, rng):
            icd = next(c for s, c, _ in codings if s == ICD)
            sct = next(((c, d) for s, c, d in codings if s == SCT), None)
            cid += 1
            rows["CONDITION_OCCURRENCE"].append({
                "condition_occurrence_id": cid, "person_id": p.idx, "condition_start_date": date,
                "condition_concept_id": concept("SNOMED", *sct) if sct else 0, "condition_source_value": icd,
                "visit_occurrence_id": vid})
        for d in p.drugs:
            did += 1
            rows["DRUG_EXPOSURE"].append({"drug_exposure_id": did, "person_id": p.idx,
                                          "drug_concept_id": concept("RxNorm", DRUGS[d], d),
                                          "drug_exposure_start_date": date, "drug_source_value": DRUGS[d],
                                          "visit_occurrence_id": vid})
        for code, value in _labs(p, rng).items():
            mid += 1
            disp, unit = LABS[code]
            rows["MEASUREMENT"].append({"measurement_id": mid, "person_id": p.idx,
                                        "measurement_concept_id": concept("LOINC", code, disp),
                                        "measurement_date": date, "value_as_number": round(float(value), 2),
                                        "unit_source_value": unit, "measurement_source_value": code,
                                        "visit_occurrence_id": vid})
    for table, data in rows.items():
        if data:
            with open(out / f"{table}.csv", "w", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(data[0]))
                w.writeheader()
                w.writerows(data)
    with open(out / "CONCEPT.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["concept_id", "concept_name", "vocabulary_id", "concept_code"])
        for (vocab, code), (cid_, name) in concepts.items():
            w.writerow([cid_, name, vocab, code])


def _gray_image(rng: np.random.Generator, size: int = 128, lesion: bool = True) -> np.ndarray:
    yy, xx = np.mgrid[0:size, 0:size]
    breast = np.exp(-(((xx - 0.1 * size) / (0.75 * size)) ** 2 + ((yy - size / 2) / (0.45 * size)) ** 2))
    img = 0.55 * breast + 0.08 * rng.standard_normal((size, size))
    if lesion:
        cx, cy = rng.integers(size // 4, 3 * size // 4, 2)
        img += 0.35 * np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * (size / 20) ** 2)))
    return np.clip(img, 0, 1)


def write_multimedia(cohort: list[Patient], out: Path, rng: np.random.Generator) -> None:
    from PIL import Image

    files = out / "files"
    dicom_dir = out / "dicom"
    files.mkdir(parents=True, exist_ok=True)
    dicom_dir.mkdir(parents=True, exist_ok=True)
    manifest: list[dict] = []
    try:
        import pydicom  # noqa: F401
        have_dicom = True
    except ImportError:
        have_dicom = False
    for p in cohort:
        if p.breast_cancer:
            for lat in ("L", "R"):
                for view in ("CC", "MLO"):
                    if have_dicom:
                        _write_dicom(dicom_dir / f"{p.mrn}_{lat}_{view}.dcm", p, lat, view, rng)
            slide = f"WSI-{p.mrn}"
            Image.fromarray(_he_image(rng, 256)).save(files / f"{slide}.png")
            manifest.append(dict(media_id=slide, patient_mrn=p.mrn, path=f"files/{slide}.png", modality="SM",
                                 mime_type="image/png", study_uid="", body_site="UBERON:0000310",
                                 finding_code="SNOMEDCT:254837009", derived_from="", acquired="2023-03-14",
                                 title="H&E whole-slide thumbnail"))
            for t in (1, 2):
                tile = f"{slide}-tile{t}"
                Image.fromarray(_he_image(rng, 64)).save(files / f"{tile}.png")
                manifest.append(dict(media_id=tile, patient_mrn=p.mrn, path=f"files/{tile}.png", modality="SM",
                                     mime_type="image/png", study_uid="", body_site="UBERON:0000310",
                                     finding_code="", derived_from=slide, acquired="2023-03-14",
                                     title=f"H&E tile {t} (20x)"))
            rep = f"PATH-{p.mrn}"
            (files / f"{rep}.txt").write_text(_report(p))
            manifest.append(dict(media_id=rep, patient_mrn=p.mrn, path=f"files/{rep}.txt", modality="DOC",
                                 mime_type="text/plain", study_uid="", body_site="BREAST",
                                 finding_code="ICD10CM:C50.9", derived_from=slide, acquired="2023-03-16",
                                 title="Surgical pathology report"))
            if rng.random() < 0.5:
                cine = f"US-{p.mrn}"
                frames = [Image.fromarray((_gray_image(rng, 96, True) * 255).astype("uint8")) for _ in range(8)]
                frames[0].save(files / f"{cine}.gif", save_all=True, append_images=frames[1:], duration=80, loop=0)
                manifest.append(dict(media_id=cine, patient_mrn=p.mrn, path=f"files/{cine}.gif", modality="US",
                                     mime_type="image/gif", study_uid=p.study_uid, body_site="BREAST",
                                     finding_code="", derived_from="", acquired="2023-03-02",
                                     title="Breast ultrasound cine loop"))
            if rng.random() < 0.3:
                au = f"DICT-{p.mrn}"
                _write_wav(files / f"{au}.wav", rng)
                manifest.append(dict(media_id=au, patient_mrn=p.mrn, path=f"files/{au}.wav", modality="AU",
                                     mime_type="audio/wav", study_uid=p.study_uid, body_site="", finding_code="",
                                     derived_from="", acquired="2023-03-02", title="Radiologist dictation"))
        elif p.htn and rng.random() < 0.25:
            cxr = f"CXR-{p.mrn}"
            Image.fromarray((_gray_image(rng, 128, False) * 255).astype("uint8")).save(files / f"{cxr}.png")
            manifest.append(dict(media_id=cxr, patient_mrn=p.mrn, path=f"files/{cxr}.png", modality="DX",
                                 mime_type="image/png", study_uid="", body_site="CHEST", finding_code="",
                                 derived_from="", acquired="2023-06-01", title="Chest radiograph"))
    with open(out / "media_manifest.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(manifest[0]))
        w.writeheader()
        w.writerows(manifest)


def _he_image(rng: np.random.Generator, size: int) -> np.ndarray:
    base = np.stack([np.full((size, size), 0.93), np.full((size, size), 0.78), np.full((size, size), 0.88)], -1)
    nuclei = rng.random((size, size)) < 0.04
    img = base - 0.05 * rng.random((size, size, 1))
    img[nuclei] = [0.42, 0.3, 0.62]
    return (np.clip(img, 0, 1) * 255).astype("uint8")


def _report(p: Patient) -> str:
    er = "positive" if p.er_pos else "negative"
    her2 = "positive (3+)" if p.her2_pos else "negative (1+)"
    return ("SURGICAL PATHOLOGY REPORT (SYNTHETIC)\n"
            f"Patient: {p.mrn}\nSpecimen: breast, core needle biopsy\n"
            "Diagnosis: invasive ductal carcinoma, grade 2.\n"
            f"Estrogen receptor: {er}. Progesterone receptor: {er}. HER2: {her2}.\n"
            + (f"Germline testing: pathogenic {p.brca_carrier} variant reported.\n" if p.brca_carrier else ""))


def _write_wav(path: Path, rng: np.random.Generator, sr: int = 8000) -> None:
    t = np.arange(sr) / sr
    sig = 0.3 * np.sin(2 * math.pi * 180 * t) * (1 + 0.5 * np.sin(2 * math.pi * 3 * t)) + 0.05 * rng.standard_normal(sr)
    data = (np.clip(sig, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data.tobytes())


def _write_dicom(path: Path, p: Patient, lat: str, view: str, rng: np.random.Generator) -> None:
    from pydicom.dataset import Dataset, FileMetaDataset
    from pydicom.uid import ExplicitVRLittleEndian, generate_uid

    meta = FileMetaDataset()
    meta.MediaStorageSOPClassUID = "1.2.840.10008.5.1.4.1.1.1.2"  # Digital Mammography X-Ray Image Storage - For Presentation
    meta.MediaStorageSOPInstanceUID = generate_uid(entropy_srcs=[p.mrn, lat, view])
    meta.TransferSyntaxUID = ExplicitVRLittleEndian
    ds = Dataset()
    ds.file_meta = meta
    ds.SOPClassUID = meta.MediaStorageSOPClassUID
    ds.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
    ds.StudyInstanceUID = p.study_uid
    ds.SeriesInstanceUID = generate_uid(entropy_srcs=[p.mrn, "series", lat])
    ds.PatientID = p.mrn
    ds.PatientName = "SYNTHETIC^PATIENT"
    ds.PatientSex = "F" if p.sex == "female" else "M"
    ds.Modality = "MG"
    ds.StudyDate = "20230302"
    ds.StudyDescription = "Bilateral mammography"
    ds.SeriesDescription = f"{lat} {view}"
    ds.BodyPartExamined = "BREAST"
    ds.ImageLaterality = lat
    ds.ViewPosition = view
    img = (_gray_image(rng, 128, lesion=(lat == "L")) * 4095).astype("uint16")
    ds.Rows, ds.Columns = img.shape
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.BitsAllocated, ds.BitsStored, ds.HighBit, ds.PixelRepresentation = 16, 12, 11, 0
    ds.PixelData = img.tobytes()
    ds.save_as(path, enforce_file_format=True)


def write_omics(cohort: list[Patient], out: Path, rng: np.random.Generator) -> None:
    out.mkdir(parents=True, exist_ok=True)
    samples = [p for p in cohort if p.sample_id]
    with open(out / "sample_sheet.tsv", "w") as fh:
        fh.write("sample_id\tpatient_mrn\ttissue\tsample_type\tcollected\tassays\n")
        for p in samples:
            fh.write(f"{p.sample_id}\t{p.mrn}\tUBERON:0000310\tprimary tumour\t2023-03-14\tWES;RNA-seq;proteome;methylome\n")
    # fixed variant catalogue so variants recur across samples
    catalogue = []
    for gene, n, sig in (("BRCA1", 2, "Pathogenic"), ("BRCA2", 2, "Pathogenic"), ("TP53", 3, "Pathogenic"),
                         ("PIK3CA", 2, "Likely_pathogenic"), ("ERBB2", 1, "Uncertain_significance"),
                         ("ESR1", 1, "Uncertain_significance")):
        _, _, chrom, start, end, _ = GENES[gene]
        for _ in range(n):
            ref, alt = rng.choice(list("ACGT"), 2, replace=False)
            catalogue.append((gene, chrom, int(rng.integers(start, end)), ref, alt, sig))
    calls: dict[int, dict[str, str]] = {i: {} for i in range(len(catalogue))}
    for p in samples:
        for i, (gene, *_rest) in enumerate(catalogue):
            hit = ((gene == p.brca_carrier and rng.random() < 0.7) or
                   (gene == "TP53" and rng.random() < 0.12) or
                   (gene == "PIK3CA" and rng.random() < (0.25 if p.er_pos else 0.08)) or
                   (gene in ("ERBB2", "ESR1") and rng.random() < 0.05))
            if hit:
                vaf = rng.normal(0.47, 0.04) if gene.startswith("BRCA") else rng.uniform(0.1, 0.45)
                calls[i][p.sample_id] = f"0/1:{vaf:.2f}"
    with open(out / "somatic_variants.vcf", "w") as fh:
        fh.write("##fileformat=VCFv4.2\n##reference=GRCh38\n##source=TriSemKG-synthetic\n")
        fh.write('##INFO=<ID=GENE,Number=1,Type=String,Description="HGNC gene symbol">\n')
        fh.write('##INFO=<ID=CLNSIG,Number=1,Type=String,Description="Clinical significance (synthetic)">\n')
        fh.write('##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n')
        fh.write('##FORMAT=<ID=VAF,Number=1,Type=Float,Description="Variant allele fraction">\n')
        fh.write("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\t" + "\t".join(p.sample_id for p in samples) + "\n")
        for i, (gene, chrom, pos, ref, alt, sig) in sorted(enumerate(catalogue), key=lambda x: (x[1][1], x[1][2])):
            gts = [calls[i].get(p.sample_id, "0/0:0.00") for p in samples]
            fh.write(f"chr{chrom}\t{pos}\t.\t{ref}\t{alt}\t60\tPASS\tGENE={gene};CLNSIG={sig}\tGT:VAF\t" + "\t".join(gts) + "\n")
    tpm, prot, meth = {}, {}, {}
    for gene, (ens, uni, *_x, base) in GENES.items():
        row, prow = [], []
        for p in samples:
            f = 1.0
            f *= 8 if gene == "ERBB2" and p.her2_pos else 1
            f *= 6 if gene in ("ESR1",) and p.er_pos else 1
            f *= 4 if gene == "PGR" and p.er_pos else 1
            v = base * f * rng.lognormal(0, 0.35)
            row.append(round(v, 2))
            prow.append(round(np.log2(v * 1000) + rng.normal(0, 0.3), 3))
        tpm[ens] = row
        if gene in ("ERBB2", "ESR1", "TP53", "BRCA1", "PGR"):
            prot[uni] = prow
    for gene in ("BRCA1", "ESR1", "PGR"):
        meth[gene] = [round(float(np.clip(rng.normal(0.78, 0.06) if (gene == "BRCA1" and not p.brca_carrier and rng.random() < 0.15)
                                          or (gene in ("ESR1", "PGR") and not p.er_pos and rng.random() < 0.5)
                                          else rng.normal(0.2, 0.08), 0, 1)), 3) for p in samples]
    cols = [p.sample_id for p in samples]
    for name, table, idx in (("rnaseq_tpm.tsv", tpm, "ensembl_gene_id"), ("proteomics_log2.tsv", prot, "uniprot_accession"),
                             ("methylation_beta.tsv", meth, "gene_symbol")):
        with open(out / name, "w") as fh:
            fh.write(idx + "\t" + "\t".join(cols) + "\n")
            for k, vals in table.items():
                fh.write(k + "\t" + "\t".join(str(v) for v in vals) + "\n")


def generate(out: str | Path, n_patients: int = 200, seed: int = 7) -> dict:
    """Write a complete synthetic multi-modal cohort under ``out``; return a summary."""
    out = Path(out)
    rng = np.random.default_rng(seed)
    cohort = make_cohort(n_patients, rng)
    write_fhir(cohort, out / "ehr" / "fhir", rng)
    write_omop(cohort, out / "ehr" / "omop", rng)
    write_multimedia(cohort, out / "multimedia", rng)
    write_omics(cohort, out / "omics", rng)
    truth = [{"mrn": p.mrn, "sex": p.sex, "breast_cancer": p.breast_cancer, "t2d": p.t2d, "hypertension": p.htn,
              "er_positive": p.er_pos, "her2_positive": p.her2_pos, "brca_carrier": p.brca_carrier or "",
              "in_fhir": p.in_fhir, "in_omop": p.in_omop, "sample_id": p.sample_id or "",
              "drugs": ";".join(p.drugs)} for p in cohort]
    with open(out / "cohort_truth.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(truth[0]))
        w.writeheader()
        w.writerows(truth)
    return {"patients": n_patients, "fhir": sum(p.in_fhir for p in cohort), "omop": sum(p.in_omop for p in cohort),
            "both": sum(p.in_fhir and p.in_omop for p in cohort), "biosamples": sum(bool(p.sample_id) for p in cohort)}
