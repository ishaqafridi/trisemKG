"""Layer 1: data source and ingestion layer."""
from . import ehr_fhir, ehr_omop, knowledge, multimedia, omics  # noqa: F401  (registers adapters)
from .base import REGISTRY, SourceAdapter, build_adapter, load_sources, register

__all__ = ["REGISTRY", "SourceAdapter", "build_adapter", "load_sources", "register"]
