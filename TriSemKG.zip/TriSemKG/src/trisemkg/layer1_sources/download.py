"""Download public reference sources for the knowledge facet.

URLs point to the canonical distribution locations at the time of writing; check
them against each provider's site, and respect each source's licence (DrugBank
and SNOMED CT in particular require registration or an affiliate licence).
"""
from __future__ import annotations

import shutil
import urllib.request
from pathlib import Path

from ..utils import LOG

SOURCES = {
    "primekg": ("https://dataverse.harvard.edu/api/access/datafile/6180620", "kg.csv",
                "PrimeKG knowledge graph (Chandak et al. 2023), CC BY 4.0"),
    "mondo": ("http://purl.obolibrary.org/obo/mondo.obo", "mondo.obo", "Mondo Disease Ontology, CC BY 4.0"),
    "hpo": ("http://purl.obolibrary.org/obo/hp.obo", "hp.obo", "Human Phenotype Ontology"),
    "go": ("http://purl.obolibrary.org/obo/go.obo", "go.obo", "Gene Ontology, CC BY 4.0"),
    "uberon": ("http://purl.obolibrary.org/obo/uberon/basic.obo", "uberon.obo", "Uberon anatomy, CC BY 3.0"),
    "mondo_sssom": ("http://purl.obolibrary.org/obo/mondo/mappings/mondo.sssom.tsv", "mondo.sssom.tsv",
                    "Mondo SSSOM mappings to ICD, OMIM, DOID and others"),
}


def download(name: str, dest: str | Path = "data/external", force: bool = False) -> Path:
    if name not in SOURCES:
        raise KeyError(f"unknown source {name}; choose from {sorted(SOURCES)}")
    url, filename, desc = SOURCES[name]
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / filename
    if target.exists() and not force:
        LOG.info("%s already present at %s", name, target)
        return target
    LOG.info("Downloading %s (%s) from %s", name, desc, url)
    req = urllib.request.Request(url, headers={"User-Agent": "TriSemKG/1.0"})
    with urllib.request.urlopen(req) as resp, open(target, "wb") as fh:  # noqa: S310 (trusted URLs)
        shutil.copyfileobj(resp, fh)
    return target
