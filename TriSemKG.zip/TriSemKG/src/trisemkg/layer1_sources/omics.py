"""Multi-omics adapters: sample sheet, VCF (genomics), expression (transcriptomics),
proteomics and DNA methylation (epigenomics)."""
from __future__ import annotations

import gzip
from collections.abc import Iterator

import numpy as np
import pandas as pd

from ..model import Code, SourceBatch
from .base import SourceAdapter, register


def _sample(b: SourceBatch, sid: str) -> str:
    return b.entity(f"sample:{sid}", "biosample", [Code("TRISEM-SAMPLE", sid)], sid)


def _gene(b: SourceBatch, system: str, gid: str) -> str:
    return b.entity(f"gene:{system}|{gid}", "gene/protein", [Code(system, gid, gid if system == "HGNC.SYMBOL" else None)],
                    gid if system == "HGNC.SYMBOL" else None)


@register("sample_sheet")
class SampleSheetAdapter(SourceAdapter):
    """TSV with sample_id, patient_mrn and optional tissue (CURIE), sample_type, collected."""

    def read(self) -> Iterator[SourceBatch]:
        df = pd.read_csv(self.path, sep="\t", dtype=str).fillna("")
        b = self.batch(self.path.name)
        for r in df.to_dict("records"):
            s = _sample(b, r["sample_id"])
            b.entities[s].attrs.update({k: r[k] for k in ("sample_type", "collected", "assays") if r.get(k)})
            p = b.entity(f"patient:{r['patient_mrn']}", "patient", [Code("TRISEM-MRN", r["patient_mrn"])],
                         r["patient_mrn"])
            b.relate("patient_biosample", p, s)
            if r.get("tissue"):
                prefix, code = r["tissue"].split(":", 1)
                a = b.entity(f"anat:{r['tissue']}", "anatomy", [Code(prefix, code)])
                b.relate("biosample_anatomy", s, a)
        yield b


@register("vcf")
class VCFAdapter(SourceAdapter):
    """Multi-sample VCF. Gene symbols are read from INFO GENE= (or the first field of
    an ANN/CSQ annotation). Non-reference genotypes become biosample_variant edges."""

    genome = "GRCh38"

    def read(self) -> Iterator[SourceBatch]:
        opener = gzip.open if self.path.suffix == ".gz" else open
        b = self.batch(self.path.name)
        samples: list[str] = []
        with opener(self.path, "rt") as fh:
            for line in fh:
                if line.startswith("##"):
                    if line.startswith("##reference="):
                        self.genome = line.split("=", 1)[1].strip()
                    continue
                cols = line.rstrip("\n").split("\t")
                if line.startswith("#CHROM"):
                    samples = cols[9:]
                    continue
                chrom, pos, vid, ref, alt, qual, filt, info = cols[:8]
                fmt = cols[8].split(":") if len(cols) > 8 else []
                infod = dict(kv.split("=", 1) if "=" in kv else (kv, True) for kv in info.split(";"))
                gene = infod.get("GENE") or (str(infod.get("ANN", "")).split("|")[3] if "ANN" in infod else None)
                for a in alt.split(","):
                    key = f"{self.genome}-{chrom.removeprefix('chr')}-{pos}-{ref}-{a}"
                    codes = [Code("TRISEM-VAR", key)] + ([Code("DBSNP", vid)] if vid not in (".", "") else [])
                    v = b.entity(f"var:{key}", "variant", codes, f"{chrom}:{pos} {ref}>{a}",
                                 chrom=chrom, pos=int(pos), ref=ref, alt=a, genome=self.genome,
                                 clinical_significance=infod.get("CLNSIG"), consequence=infod.get("CSQ_TERM"),
                                 filter=filt)
                    if gene:
                        b.relate("variant_protein", v, _gene(b, "HGNC.SYMBOL", gene))
                    for s, call in zip(samples, cols[9:]):
                        fields = dict(zip(fmt, call.split(":")))
                        gt = fields.get("GT", "./.")
                        if gt.replace("|", "/") in ("0/0", "./.", "."):
                            continue
                        vaf = fields.get("VAF") or fields.get("AF")
                        b.relate("biosample_variant", _sample(b, s), v, genotype=gt,
                                 vaf=float(vaf) if vaf not in (None, ".") else None)
        yield b


class _MatrixAdapter(SourceAdapter):
    """Feature-by-sample matrix; first column holds feature identifiers."""

    relation = ""
    default_system = "ENSEMBL"
    transform = staticmethod(lambda x: x)

    def read(self) -> Iterator[SourceBatch]:
        df = pd.read_csv(self.path, sep="\t", index_col=0)
        system = self.options.get("id_system", self.default_system)
        b = self.batch(self.path.name)
        for gid, sid, value, extra in self.select(df):
            b.relate(self.relation, _sample(b, sid), _gene(b, system, str(gid)), value=round(float(value), 4),
                     **extra)
        yield b

    def select(self, df: pd.DataFrame):
        z_thr = float(self.options.get("z_threshold", 1.0))
        x = self.transform(df.astype(float))
        mu, sd = x.mean(axis=1), x.std(axis=1).replace(0, np.nan)
        z = x.sub(mu, axis=0).div(sd, axis=0)
        for gid in df.index:
            for sid in df.columns:
                zv = z.at[gid, sid]
                if pd.notna(zv) and abs(zv) >= z_thr:
                    yield gid, sid, df.at[gid, sid], {"zscore": round(float(zv), 3),
                                                     "direction": "up" if zv > 0 else "down"}


@register("expression")
class ExpressionAdapter(_MatrixAdapter):
    """RNA-seq TPM matrix; z-scores on log2(TPM+1); |z| >= z_threshold becomes an edge."""

    relation = "biosample_expression"
    transform = staticmethod(lambda x: np.log2(x + 1))


@register("proteomics")
class ProteomicsAdapter(_MatrixAdapter):
    """Log2 protein intensities keyed by UniProt accession."""

    relation = "biosample_protein_abundance"
    default_system = "UniProtKB"


@register("methylation")
class MethylationAdapter(_MatrixAdapter):
    """Gene-level methylation beta values; beta >= beta_threshold becomes an edge."""

    relation = "biosample_methylation"
    default_system = "HGNC.SYMBOL"

    def select(self, df: pd.DataFrame):
        thr = float(self.options.get("beta_threshold", 0.6))
        for gid in df.index:
            for sid in df.columns:
                v = float(df.at[gid, sid])
                if v >= thr:
                    yield gid, sid, v, {"state": "hypermethylated"}
