"""HL7 FHIR R4 adapter (Bundle JSON files or NDJSON exports)."""
from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from ..model import Code, SourceBatch
from .base import SourceAdapter, register

MRN_SYSTEMS = {"urn:trisemkg:mrn", "http://hospital.example.org/mrn"}


def _codes(cc: dict[str, Any] | None) -> list[Code]:
    if not cc:
        return []
    out = [Code(c.get("system", "unknown"), str(c["code"]), c.get("display"))
           for c in cc.get("coding", []) if c.get("code")]
    return out


def _ref_id(ref: str | None) -> str | None:
    if not ref:
        return None
    return ref.split("/")[-1].replace("urn:uuid:", "")


@register("fhir")
class FHIRAdapter(SourceAdapter):
    """Reads Patient, Encounter, Condition, MedicationRequest, Observation, Procedure,
    ImagingStudy and Media resources."""

    def _files(self) -> list[Path]:
        if self.path.is_file():
            return [self.path]
        return sorted(p for p in self.path.rglob("*") if p.suffix in {".json", ".ndjson"})

    def read(self) -> Iterator[SourceBatch]:
        for f in self._files():
            if f.suffix == ".ndjson":
                resources = [json.loads(line) for line in f.read_text().splitlines() if line.strip()]
            else:
                doc = json.loads(f.read_text())
                resources = [e["resource"] for e in doc.get("entry", [])] if doc.get("resourceType") == "Bundle" else [doc]
            yield self._convert(f.name, resources)

    def _convert(self, name: str, resources: list[dict[str, Any]]) -> SourceBatch:
        b = self.batch(name)
        patients: dict[str, str] = {}
        for r in resources:
            if r.get("resourceType") != "Patient":
                continue
            mrn = next((i["value"] for i in r.get("identifier", [])
                        if i.get("system") in MRN_SYSTEMS
                        or any(c.get("code") == "MR" for c in i.get("type", {}).get("coding", []))), r["id"])
            patients[r["id"]] = b.entity(f"Patient/{r['id']}", "patient", [Code("TRISEM-MRN", mrn)], mrn,
                                         gender=r.get("gender"), birth_date=r.get("birthDate"))

        def subject(r: dict[str, Any]) -> str | None:
            pid = _ref_id((r.get("subject") or r.get("patient") or {}).get("reference"))
            return patients.get(pid) if pid else None

        def concept(entity_type: str, cc: dict[str, Any] | None) -> str | None:
            codes = _codes(cc)
            if not codes:
                return None
            lid = f"concept:{entity_type}:{codes[0].system}|{codes[0].code}"
            name = (cc or {}).get("text") or codes[0].display
            return b.entity(lid, entity_type, codes, name)

        for r in resources:
            rt, p = r.get("resourceType"), None
            if rt in (None, "Patient"):
                continue
            p = subject(r)
            if p is None:
                continue
            enc = _ref_id((r.get("encounter") or {}).get("reference"))
            if rt == "Encounter":
                e = b.entity(f"Encounter/{r['id']}", "encounter", [Code("TRISEM-ENC", f"fhir-{r['id']}")],
                             r.get("class", {}).get("code", "encounter"),
                             start=r.get("period", {}).get("start"), status=r.get("status"))
                b.relate("patient_encounter", p, e)
            elif rt == "Condition":
                c = concept("disease", r.get("code"))
                if c:
                    b.relate("patient_disease", p, c, onset=r.get("onsetDateTime"), encounter=enc,
                             clinical_status=(_codes(r.get("clinicalStatus")) or [Code("", "")])[0].code or None)
            elif rt == "MedicationRequest":
                c = concept("drug", r.get("medicationCodeableConcept"))
                if c:
                    b.relate("patient_drug", p, c, authored=r.get("authoredOn"), status=r.get("status"), encounter=enc)
            elif rt == "Observation":
                c = concept("lab_test", r.get("code"))
                vq = r.get("valueQuantity") or {}
                if c and "value" in vq:
                    b.relate("patient_labtest", p, c, value=float(vq["value"]), unit=vq.get("unit") or vq.get("code"),
                             date=r.get("effectiveDateTime"), encounter=enc)
            elif rt == "Procedure":
                c = concept("procedure", r.get("code"))
                if c:
                    b.relate("patient_procedure", p, c, date=r.get("performedDateTime"), encounter=enc)
            elif rt == "ImagingStudy":
                uid = next((i["value"].replace("urn:oid:", "") for i in r.get("identifier", [])
                            if i.get("system") == "urn:dicom:uid"), r["id"])
                s = b.entity(f"ImagingStudy/{r['id']}", "imaging_study", [Code("DICOM-UID", uid)],
                             r.get("description") or f"Imaging study {uid}",
                             modality=",".join(m.get("code", "") for m in r.get("modality", [])),
                             started=r.get("started"))
                b.relate("patient_study", p, s)
            elif rt == "Media":
                content = r.get("content", {})
                m = b.entity(f"Media/{r['id']}", "media_object", [Code("TRISEM-MEDIA", r["id"])],
                             content.get("title") or r["id"], uri=content.get("url"),
                             mime_type=content.get("contentType"),
                             modality=(_codes(r.get("modality")) or [Code("", "OT")])[0].code)
                b.relate("patient_media", p, m)
        return b
