"""Pipeline configuration loading."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class PipelineConfig:
    root: Path
    schema: Path
    mappings_dir: Path
    output_dir: Path
    sources: list[dict[str, Any]]
    semantic: dict[str, Any] = field(default_factory=dict)
    knowledge: dict[str, Any] = field(default_factory=dict)
    project: str = "TriSemKG"

    @classmethod
    def load(cls, path: str | Path, root: str | Path | None = None,
             overrides: dict[str, Any] | None = None) -> PipelineConfig:
        path = Path(path)
        raw = yaml.safe_load(path.read_text())
        raw.update(overrides or {})
        base = Path(root) if root else path.resolve().parent.parent
        res = lambda p: (base / p) if not Path(p).is_absolute() else Path(p)  # noqa: E731
        sources = []
        for s in raw.get("sources", []):
            s = dict(s)
            if "path" in s:
                s["path"] = str(res(s["path"]))
            sources.append(s)
        semantic = dict(raw.get("semantic", {}))
        if semantic.get("phenotype_rules"):
            semantic["phenotype_rules"] = str(res(semantic["phenotype_rules"]))
        return cls(root=base, schema=res(raw["schema"]), mappings_dir=res(raw["mappings_dir"]),
                   output_dir=res(raw.get("output_dir", "output")), sources=sources,
                   semantic=semantic, knowledge=dict(raw.get("knowledge", {})),
                   project=raw.get("project", "TriSemKG"))
