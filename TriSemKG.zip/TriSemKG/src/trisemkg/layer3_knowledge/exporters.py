"""Export formats: PrimeKG CSV, Neo4j bulk import, RDF (Turtle / N-Triples),
GraphML and a torch-free heterogeneous-graph tensor bundle for PyG/DGL."""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .graph import KnowledgeGraph

VOCAB = "https://w3id.org/trisemkg/vocab/"


def class_name(node_type: str) -> str:
    return "".join(p.capitalize() for p in re.split(r"[/_ -]+", node_type))


def rel_name(relation: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", relation).strip("_")


def export_primekg(kg: KnowledgeGraph, out: Path, bidirectional: bool = True) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    kg.primekg_df(bidirectional).to_csv(out / "kg.csv", index=False)
    return out / "kg.csv"


def export_neo4j(kg: KnowledgeGraph, out: Path) -> Path:
    """CSV files for `neo4j-admin database import full` plus the import command."""
    out.mkdir(parents=True, exist_ok=True)
    nd = kg.nodes_df()
    args = []
    for t, grp in nd.groupby("node_type"):
        label = class_name(t)
        f = out / f"nodes_{label}.csv"
        df = pd.DataFrame({"id:ID": grp["node_id"], "name": grp["node_name"], "node_type": t,
                           "facet": grp["facet"], "mapping_status": grp["mapping_status"],
                           "confidence:float": grp["confidence"], "xrefs:string[]": grp["xrefs"].str.replace("|", ";"),
                           "attributes": grp["attributes"], ":LABEL": f"{label};{class_name(grp['facet'].iloc[0])}Entity"})
        df.to_csv(f, index=False)
        args.append(f"--nodes={f.name}")
    ed = kg.edges_df()
    rel = pd.DataFrame({":START_ID": ed["x_id"], ":END_ID": ed["y_id"], ":TYPE": ed["relation"].map(lambda r: rel_name(r).upper()),
                        "display": ed["display_relation"], "confidence:float": ed["confidence"],
                        "justification": ed["justification"], "sources": ed["sources"], "attributes": ed["attributes"]})
    rel.to_csv(out / "relationships.csv", index=False)
    args.append("--relationships=relationships.csv")
    (out / "import.sh").write_text("#!/usr/bin/env bash\n# Run from this directory with Neo4j stopped.\n"
                                   "neo4j-admin database import full trisemkg --overwrite-destination \\\n  "
                                   + " \\\n  ".join(args) + "\n")
    return out


def _lit(v) -> str:
    s = str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "")
    return f'"{s}"'


def export_rdf(kg: KnowledgeGraph, out: Path, provenance: bool = True, turtle_limit: int = 200_000) -> Path:
    """Write RDF. Graphs up to ``turtle_limit`` edges go through rdflib as Turtle;
    larger graphs are streamed as N-Triples to keep memory flat."""
    out.mkdir(parents=True, exist_ok=True)
    ex = kg.schema.expand
    RDF, RDFS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "http://www.w3.org/2000/01/rdf-schema#"
    SKOS, PROV, XSD = "http://www.w3.org/2004/02/skos/core#", "http://www.w3.org/ns/prov#", "http://www.w3.org/2001/XMLSchema#"

    def triples():
        for n in kg.nodes.values():
            s = f"<{ex(n.id)}>"
            yield s, f"<{RDF}type>", f"<{VOCAB}{class_name(n.type)}>"
            yield s, f"<{RDFS}label>", _lit(n.name)
            yield s, f"<{VOCAB}facet>", _lit(n.facet)
            yield s, f"<{VOCAB}mappingStatus>", _lit(n.mapping_status)
            for x in sorted(n.xrefs):
                if ":" in x:
                    yield s, f"<{SKOS}exactMatch>", f"<{ex(x)}>"
            for k in ("uri", "mime_type", "modality", "sha256", "gender", "genome", "clinical_significance"):
                if k in n.attrs and n.attrs[k] is not None:
                    yield s, f"<{VOCAB}{k}>", _lit(n.attrs[k])
        for i, e in enumerate(kg.edges.values()):
            s, p, o = f"<{ex(e.x)}>", f"<{VOCAB}{rel_name(e.relation)}>", f"<{ex(e.y)}>"
            yield s, p, o
            if provenance:
                st = f"<https://w3id.org/trisemkg/statement/{i}>"
                yield st, f"<{RDF}type>", f"<{RDF}Statement>"
                yield st, f"<{RDF}subject>", s
                yield st, f"<{RDF}predicate>", p
                yield st, f"<{RDF}object>", o
                yield st, f"<{VOCAB}confidence>", f'"{e.confidence:.3f}"^^<{XSD}decimal>'
                yield st, f"<{VOCAB}justification>", _lit(e.justification)
                for src in sorted(e.sources):
                    yield st, f"<{PROV}wasDerivedFrom>", _lit(src)

    nt = out / "trisemkg.nt"
    with open(nt, "w", encoding="utf-8") as fh:
        for t in triples():
            fh.write(" ".join(t) + " .\n")
    if len(kg.edges) <= turtle_limit:
        try:
            from rdflib import Graph
            g = Graph()
            g.parse(nt, format="nt")
            for prefix in ("MONDO", "HP", "GO", "UBERON", "NCBIGene", "DRUGBANK", "LOINC", "SNOMEDCT", "TRISEM"):
                if prefix in kg.schema.prefixes:
                    g.bind(prefix.lower(), kg.schema.prefixes[prefix])
            g.bind("tsv", VOCAB)
            g.bind("prov", PROV)
            g.bind("skos", SKOS)
            g.serialize(out / "trisemkg.ttl", format="turtle")
            return out / "trisemkg.ttl"
        except ImportError:
            pass
    return nt


def export_graphml(kg: KnowledgeGraph, out: Path) -> Path:
    import networkx as nx

    out.mkdir(parents=True, exist_ok=True)
    g = nx.MultiDiGraph()
    for n in kg.nodes.values():
        g.add_node(n.id, name=n.name, node_type=n.type, facet=n.facet)
    for e in kg.edges.values():
        g.add_edge(e.x, e.y, key=e.relation, relation=e.relation, confidence=e.confidence)
    nx.write_graphml(g, out / "trisemkg.graphml")
    return out / "trisemkg.graphml"


def export_hetero_tensors(kg: KnowledgeGraph, out: Path) -> Path:
    """Per-type node id lists and per-relation edge_index arrays (NumPy .npz).

    Load into PyTorch Geometric with::

        data = HeteroData()
        for (src, rel, dst), ei in edges.items(): data[src, rel, dst].edge_index = torch.from_numpy(ei)
    """
    out.mkdir(parents=True, exist_ok=True)
    local = {}
    mapping = {}
    for t in sorted({n.type for n in kg.nodes.values()}):
        ids = sorted(n.id for n in kg.nodes.values() if n.type == t)
        mapping[t] = ids
        local.update({nid: i for i, nid in enumerate(ids)})
    arrays, meta = {}, []
    by_rel: dict[tuple[str, str, str], list[tuple[int, int]]] = {}
    for e in kg.edges.values():
        key = (kg.nodes[e.x].type, e.relation, kg.nodes[e.y].type)
        by_rel.setdefault(key, []).append((local[e.x], local[e.y]))
    for i, (key, pairs) in enumerate(sorted(by_rel.items())):
        arrays[f"edge_index_{i}"] = np.array(pairs, dtype=np.int64).T
        meta.append({"array": f"edge_index_{i}", "src_type": key[0], "relation": key[1], "dst_type": key[2],
                     "n_edges": len(pairs)})
    np.savez_compressed(out / "edge_index.npz", **arrays)
    (out / "node_mapping.json").write_text(json.dumps(mapping, indent=1))
    (out / "edge_types.json").write_text(json.dumps(meta, indent=1))
    return out


EXPORTERS = {"primekg": export_primekg, "neo4j": export_neo4j, "rdf": export_rdf, "graphml": export_graphml,
             "tensors": export_hetero_tensors}
