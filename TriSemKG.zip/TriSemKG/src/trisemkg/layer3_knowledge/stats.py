"""Descriptive statistics of the graph and of the ontology-mapping process."""
from __future__ import annotations

from collections import Counter

import pandas as pd

from .graph import KnowledgeGraph

MAPPED = {"canonical", "mapped", "hierarchical", "lexical", "local"}


def compute_stats(kg: KnowledgeGraph, mapping_log: list[dict] | None = None) -> dict:
    nt = Counter(n.type for n in kg.nodes.values())
    nf = Counter(n.facet for n in kg.nodes.values())
    er = Counter(e.relation for e in kg.edges.values())
    ef = Counter(kg._edge_facet(e) for e in kg.edges.values())
    patients = kg.nodes_of("patient")
    modal = Counter()
    for p in patients:
        facets = {kg.nodes[e.y].facet for e in kg.out_edges(p.id)}
        has = ("clinical" in facets or any(kg.nodes[e.y].type in ("disease", "drug", "lab_test") for e in kg.out_edges(p.id)),
               "multimedia" in facets, "omics" in facets)
        modal["+".join(n for n, h in zip(("EHR", "multimedia", "omics"), has) if h) or "none"] += 1
    stats = {"nodes": len(kg.nodes), "edges": len(kg.edges), "node_types": dict(nt), "node_facets": dict(nf),
             "relations": dict(er), "edge_facets": dict(ef), "patients_by_modalities": dict(modal),
             "cross_facet_edges": sum(v for k, v in ef.items() if "-" in k)}
    if mapping_log:
        df = pd.DataFrame(mapping_log).drop_duplicates(["entity_type", "subject_id", "object_id"])
        cov = {}
        for t, g in df.groupby("entity_type"):
            cov[t] = {"entities": int(len(g)), "mapped_pct": round(100 * g["status"].isin(MAPPED).mean(), 1),
                      **{s: int(c) for s, c in g["status"].value_counts().items()}}
        stats["mapping_coverage"] = cov
    return stats


def stats_markdown(stats: dict) -> str:
    lines = ["# TriSemKG build statistics", "", f"Nodes: **{stats['nodes']:,}**  Edges: **{stats['edges']:,}**  "
             f"Cross-facet edges: **{stats['cross_facet_edges']:,}**", "", "## Nodes by type", "",
             "| Node type | Count |", "| --- | ---: |"]
    lines += [f"| {k} | {v:,} |" for k, v in sorted(stats["node_types"].items(), key=lambda x: -x[1])]
    lines += ["", "## Edges by relation", "", "| Relation | Count |", "| --- | ---: |"]
    lines += [f"| {k} | {v:,} |" for k, v in sorted(stats["relations"].items(), key=lambda x: -x[1])]
    lines += ["", "## Patients by available modalities", "", "| Modalities | Patients |", "| --- | ---: |"]
    lines += [f"| {k} | {v} |" for k, v in sorted(stats["patients_by_modalities"].items(), key=lambda x: -x[1])]
    if "mapping_coverage" in stats:
        lines += ["", "## Ontology mapping coverage (distinct source codes)", "",
                  "| Entity type | Distinct codes | Mapped % | Canonical | Curated | Hierarchical | Lexical | Unmapped |",
                  "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
        for t, c in sorted(stats["mapping_coverage"].items()):
            lines.append(f"| {t} | {c['entities']} | {c['mapped_pct']} | {c.get('canonical', 0)} | {c.get('mapped', 0)} | "
                         f"{c.get('hierarchical', 0)} | {c.get('lexical', 0)} | {c.get('unmapped', 0)} |")
    return "\n".join(lines) + "\n"
