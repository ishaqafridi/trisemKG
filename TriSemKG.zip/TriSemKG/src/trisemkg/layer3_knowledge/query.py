"""Precision-medicine queries over the integrated graph."""
from __future__ import annotations

from collections import defaultdict

import pandas as pd

from .graph import KnowledgeGraph

PATHOGENIC = {"Pathogenic", "Likely_pathogenic", "Pathogenic/Likely_pathogenic"}


def altered_genes(kg: KnowledgeGraph, patient: str) -> dict[str, list[str]]:
    """Genes altered in a patient's biosamples, with the omics evidence for each."""
    ev: dict[str, list[str]] = defaultdict(list)
    for pb in kg.out_edges(patient, "patient_biosample"):
        s = pb.y
        for bv in kg.out_edges(s, "biosample_variant"):
            v = kg.nodes[bv.y]
            if v.attrs.get("clinical_significance") in PATHOGENIC:
                for vg in kg.out_edges(bv.y, "variant_protein"):
                    ev[vg.y].append(f"{v.attrs.get('clinical_significance')} variant {v.name} (VAF {bv.attrs.get('vaf')})")
        for rel, label in (("biosample_expression", "mRNA"), ("biosample_protein_abundance", "protein")):
            for e in kg.out_edges(s, rel):
                if e.attrs.get("direction") == "up":
                    ev[e.y].append(f"{label} overexpressed (z={e.attrs.get('zscore')})")
        for e in kg.out_edges(s, "biosample_methylation"):
            ev[e.y].append(f"promoter hypermethylation (beta={e.attrs.get('value')})")
    return dict(ev)


def drug_candidates(kg: KnowledgeGraph, patient: str) -> pd.DataFrame:
    """Rank drugs whose predictive biomarker is altered in the patient and whose
    indication matches one of the patient's diagnoses."""
    diseases = {e.y for e in kg.out_edges(patient, "patient_disease")}
    current = {e.y for e in kg.out_edges(patient, "patient_drug")}
    genes = altered_genes(kg, patient)
    rows = []
    for d in kg.nodes_of("drug"):
        markers = [e.y for e in kg.out_edges(d.id, "drug_biomarker") if e.y in genes]
        if not markers:
            continue
        indicated = [e.y for e in kg.out_edges(d.id, "indication") if e.y in diseases]
        score = len(markers) + (1.0 if indicated else 0.0)
        rows.append({"drug_id": d.id, "drug": d.name, "score": score,
                     "biomarkers": ", ".join(kg.nodes[g].name for g in markers),
                     "indicated_for_patient_diagnosis": ", ".join(kg.nodes[x].name for x in indicated) or "no",
                     "already_prescribed": d.id in current,
                     "evidence": " | ".join(f"{kg.nodes[g].name}: {'; '.join(genes[g])}" for g in markers)})
    cols = ["drug_id", "drug", "score", "biomarkers", "indicated_for_patient_diagnosis", "already_prescribed", "evidence"]
    return pd.DataFrame(rows, columns=cols).sort_values("score", ascending=False, ignore_index=True)


def patient_profile(kg: KnowledgeGraph, patient: str) -> set[str]:
    feats = set()
    for rel in ("patient_disease", "patient_phenotype", "patient_drug"):
        feats |= {f"{rel}:{e.y}" for e in kg.out_edges(patient, rel)}
    feats |= {f"gene:{g}" for g in altered_genes(kg, patient)}
    return feats


def similar_patients(kg: KnowledgeGraph, patient: str, k: int = 10) -> pd.DataFrame:
    """Jaccard similarity over diagnoses, phenotypes, drugs and altered genes."""
    ref = patient_profile(kg, patient)
    rows = []
    for p in kg.nodes_of("patient"):
        if p.id == patient:
            continue
        other = patient_profile(kg, p.id)
        union = ref | other
        if union:
            rows.append({"patient": p.id, "jaccard": round(len(ref & other) / len(union), 3),
                         "shared": len(ref & other)})
    return pd.DataFrame(rows, columns=["patient", "jaccard", "shared"]).sort_values(
        ["jaccard", "shared"], ascending=False, ignore_index=True).head(k)


def media_evidence(kg: KnowledgeGraph, disease: str) -> pd.DataFrame:
    """Multimedia objects labelled as evidence for a disease, with their patient and modality."""
    rows = []
    for e in kg.in_edges(disease, "media_disease"):
        m = kg.nodes[e.x]
        owner = next((pe.x for pe in kg.in_edges(m.id, "patient_media")), "")
        rows.append({"media_id": m.id, "patient": owner, "modality": m.attrs.get("modality"),
                     "mime_type": m.attrs.get("mime_type"), "title": m.name, "uri": m.attrs.get("uri")})
    return pd.DataFrame(rows, columns=["media_id", "patient", "modality", "mime_type", "title", "uri"])


def patient_summary(kg: KnowledgeGraph, patient: str) -> dict:
    out: dict[str, list[str]] = defaultdict(list)
    for e in kg.out_edges(patient):
        n = kg.nodes[e.y]
        extra = f" (mean {e.attrs['value_mean']} {e.attrs.get('unit', '')}".rstrip() + ")" if "value_mean" in e.attrs else ""
        out[kg.display(e.relation)].append(f"{n.name} [{n.id}]{extra}")
    return dict(out)
