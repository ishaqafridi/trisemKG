"""Content features for multimedia objects.

Handcrafted, dependency-light descriptors are computed for every media object whose
file is reachable, so multimedia nodes carry a numeric representation that graph ML
models can use alongside topology:

* images (PNG/JPEG/TIFF/GIF/DICOM): 16-bin intensity histogram, mean, std, entropy,
  mean gradient magnitude and, for multi-frame objects, frame count and temporal change;
* audio (WAV): duration, RMS, zero-crossing rate, spectral centroid, 8 band energies;
* text documents: 32-dimensional hashed bag of words plus length.

Deep encoders (e.g. a pathology foundation model, CLIP, a speech encoder) can be
registered in ``EXTRACTORS`` with the same signature ``f(path) -> dict[str, float]``.
"""
from __future__ import annotations

import hashlib
import re
import wave
from collections.abc import Callable
from pathlib import Path

import numpy as np
import pandas as pd

from ..utils import LOG
from .graph import KnowledgeGraph


def _img_stats(arr: np.ndarray) -> dict[str, float]:
    a = arr.astype(float)
    a = (a - a.min()) / (np.ptp(a) or 1.0)
    hist, _ = np.histogram(a, bins=16, range=(0, 1))
    p = hist / hist.sum()
    gy, gx = np.gradient(a)
    feats = {f"hist_{i:02d}": float(v) for i, v in enumerate(p)}
    feats.update(mean=float(a.mean()), std=float(a.std()), entropy=float(-(p[p > 0] * np.log2(p[p > 0])).sum()),
                 gradient=float(np.hypot(gx, gy).mean()), height=float(arr.shape[0]), width=float(arr.shape[1]))
    return feats


def image_features(path: Path) -> dict[str, float]:
    if path.suffix.lower() == ".dcm":
        import pydicom
        arr = pydicom.dcmread(path).pixel_array
        return {**_img_stats(arr), "frames": 1.0}
    from PIL import Image, ImageSequence
    im = Image.open(path)
    frames = [np.asarray(f.convert("L"), dtype=float) for f in ImageSequence.Iterator(im)]
    feats = _img_stats(frames[0])
    feats["frames"] = float(len(frames))
    feats["temporal_change"] = float(np.mean([np.abs(b - a).mean() for a, b in zip(frames, frames[1:])])) / 255 if len(frames) > 1 else 0.0
    return feats


def audio_features(path: Path) -> dict[str, float]:
    with wave.open(str(path)) as w:
        sr, n = w.getframerate(), w.getnframes()
        x = np.frombuffer(w.readframes(n), dtype="<i2").astype(float) / 32768
    spec = np.abs(np.fft.rfft(x))
    freqs = np.fft.rfftfreq(len(x), 1 / sr)
    bands = np.array_split(spec ** 2, 8)
    tot = sum(b.sum() for b in bands) or 1.0
    feats = {"duration_s": n / sr, "rms": float(np.sqrt((x ** 2).mean())),
             "zcr": float(np.mean(np.abs(np.diff(np.sign(x))) > 0)),
             "spectral_centroid": float((freqs * spec).sum() / (spec.sum() or 1))}
    feats.update({f"band_{i}": float(b.sum() / tot) for i, b in enumerate(bands)})
    return feats


def text_features(path: Path, dims: int = 32) -> dict[str, float]:
    words = re.findall(r"[a-z0-9]+", path.read_text(errors="ignore").lower())
    v = np.zeros(dims)
    for w in words:
        v[int(hashlib.md5(w.encode()).hexdigest(), 16) % dims] += 1
    v = v / (np.linalg.norm(v) or 1)
    return {"n_words": float(len(words)), **{f"bow_{i:02d}": float(x) for i, x in enumerate(v)}}


EXTRACTORS: dict[str, Callable[[Path], dict[str, float]]] = {"image": image_features, "audio": audio_features,
                                                              "text": text_features}


def family(mime: str) -> str | None:
    if mime.startswith("image/") or mime == "application/dicom":
        return "image"
    if mime.startswith("audio/"):
        return "audio"
    if mime.startswith("text/"):
        return "text"
    return None


def extract_media_features(kg: KnowledgeGraph, out: Path) -> dict[str, int]:
    """Compute features, store one CSV per media family and attach summary attributes to nodes."""
    out.mkdir(parents=True, exist_ok=True)
    rows: dict[str, list[dict]] = {}
    for n in kg.nodes_of("media_object"):
        uri, mime = n.attrs.get("uri"), n.attrs.get("mime_type", "")
        fam = family(mime)
        if not uri or not fam or not Path(uri).exists():
            continue
        try:
            f = EXTRACTORS[fam](Path(uri))
        except Exception as exc:  # a broken file must not stop the build
            LOG.warning("feature extraction failed for %s: %s", n.id, exc)
            continue
        rows.setdefault(fam, []).append({"node_id": n.id, "modality": n.attrs.get("modality"), **f})
        n.attrs["feature_set"] = f"{fam}_v1"
        for k in ("width", "height", "frames", "duration_s", "n_words"):
            if k in f:
                n.attrs[k] = f[k]
    counts = {}
    for fam, data in rows.items():
        pd.DataFrame(data).to_csv(out / f"media_features_{fam}.csv", index=False)
        counts[fam] = len(data)
    LOG.info("Layer 3: media features %s", counts)
    return counts
