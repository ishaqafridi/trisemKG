"""Layer 3 quality checks: schema conformance, completeness and identifier health."""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .graph import KnowledgeGraph


def validate(kg: KnowledgeGraph, low_confidence: float = 0.6) -> dict:
    s = kg.schema
    issues: dict[str, list] = defaultdict(list)
    for e in kg.edges.values():
        if e.x not in kg.nodes or e.y not in kg.nodes:
            issues["dangling_edges"].append(list(e.key))
            continue
        err = s.check_edge(e.relation, kg.nodes[e.x].type, kg.nodes[e.y].type)
        if err:
            issues["schema_violations"].append({"edge": list(e.key), "error": err})
        if e.confidence < low_confidence:
            issues["low_confidence_edges"].append({"edge": list(e.key), "confidence": e.confidence})
    degree = Counter()
    for e in kg.edges.values():
        degree[e.x] += 1
        degree[e.y] += 1
    names = defaultdict(set)
    for n in kg.nodes.values():
        spec = s.node_types[n.type]
        prefix = n.id.split(":", 1)[0]
        if spec.get("identity") == "ontology" and prefix != spec.get("canonical_prefix"):
            issues["non_canonical_identifiers"].append({"node": n.id, "type": n.type, "status": n.mapping_status})
        for attr in spec.get("required_attrs", []):
            if attr not in n.attrs:
                issues["missing_required_attributes"].append({"node": n.id, "attribute": attr})
        if degree[n.id] == 0:
            issues["isolated_nodes"].append(n.id)
        if spec.get("identity") == "ontology":
            names[(n.type, n.name.lower())].add(n.id)
    for (t, name), ids in names.items():
        if len(ids) > 1:
            issues["possible_duplicates"].append({"type": t, "name": name, "ids": sorted(ids)})
    blocking = len(issues["dangling_edges"]) + len(issues["schema_violations"])
    return {"passed": blocking == 0, "n_nodes": len(kg.nodes), "n_edges": len(kg.edges),
            "counts": {k: len(v) for k, v in issues.items()},
            "issues": {k: v[:200] for k, v in issues.items()}}


def shacl_validate(ttl_path: Path, shapes_path: Path) -> dict:
    """Run SHACL validation on an RDF export when pyshacl is installed."""
    try:
        from pyshacl import validate as shacl
        from rdflib import Graph
    except ImportError:
        return {"skipped": "pyshacl not installed"}
    data, shapes = Graph().parse(ttl_path), Graph().parse(shapes_path)
    conforms, _g, text = shacl(data, shacl_graph=shapes, inference="none")
    return {"conforms": bool(conforms), "report": text[:5000]}
