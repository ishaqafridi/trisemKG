"""The assembled knowledge graph and its tabular (PrimeKG-compatible) views."""
from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Iterable
from pathlib import Path

import pandas as pd

from ..layer2_semantic.integrator import IntegrationResult
from ..layer2_semantic.schema import Schema
from ..model import Edge, Node

FACET_ORDER = {"knowledge": 0, "clinical": 1, "multimedia": 2, "omics": 3}


class KnowledgeGraph:
    def __init__(self, schema: Schema, nodes: dict[str, Node], edges: dict[tuple[str, str, str], Edge]) -> None:
        self.schema, self.nodes, self.edges = schema, nodes, edges
        ordered = sorted(nodes.values(), key=lambda n: (FACET_ORDER.get(n.facet, 9), n.type, n.id))
        self.index = {n.id: i for i, n in enumerate(ordered)}
        self._out: dict[str, list[Edge]] = defaultdict(list)
        self._in: dict[str, list[Edge]] = defaultdict(list)
        for e in edges.values():
            self._out[e.x].append(e)
            self._in[e.y].append(e)

    @classmethod
    def from_integration(cls, res: IntegrationResult, schema: Schema) -> KnowledgeGraph:
        return cls(schema, res.nodes, res.edges)

    # ---------- navigation ----------
    def out_edges(self, node_id: str, relation: str | None = None) -> list[Edge]:
        return [e for e in self._out.get(node_id, []) if relation is None or e.relation == relation]

    def in_edges(self, node_id: str, relation: str | None = None) -> list[Edge]:
        return [e for e in self._in.get(node_id, []) if relation is None or e.relation == relation]

    def nodes_of(self, node_type: str) -> list[Node]:
        return [n for n in self.nodes.values() if n.type == node_type]

    def display(self, relation: str) -> str:
        return self.schema.relations.get(relation, {}).get("display", relation)

    # ---------- tables ----------
    def nodes_df(self) -> pd.DataFrame:
        rows = []
        for n in sorted(self.nodes.values(), key=lambda n: self.index[n.id]):
            rows.append({"node_index": self.index[n.id], "node_id": n.id, "node_type": n.type, "node_name": n.name,
                         "node_source": n.id.split(":", 1)[0], "facet": n.facet, "mapping_status": n.mapping_status,
                         "confidence": round(n.confidence, 3), "xrefs": "|".join(sorted(n.xrefs)),
                         "sources": "|".join(sorted(n.sources)),
                         "attributes": json.dumps(n.attrs, default=str, sort_keys=True) if n.attrs else ""})
        return pd.DataFrame(rows)

    def edges_df(self) -> pd.DataFrame:
        rows = []
        for e in self.edges.values():
            rows.append({"relation": e.relation, "display_relation": self.display(e.relation),
                         "x_index": self.index[e.x], "x_id": e.x, "y_index": self.index[e.y], "y_id": e.y,
                         "facet": self._edge_facet(e), "confidence": round(e.confidence, 3),
                         "justification": e.justification, "sources": "|".join(sorted(e.sources)),
                         "attributes": json.dumps(e.attrs, default=str, sort_keys=True) if e.attrs else ""})
        return pd.DataFrame(rows).sort_values(["relation", "x_index", "y_index"], ignore_index=True)

    def primekg_df(self, bidirectional: bool = True) -> pd.DataFrame:
        """Exactly PrimeKG's kg.csv columns so PrimeKG/TxGNN tooling can read the graph."""
        def side(nid: str) -> dict:
            n = self.nodes[nid]
            prefix, local = nid.split(":", 1)
            return {"index": self.index[nid], "id": local, "type": n.type, "name": n.name, "source": prefix}
        rows = []
        for e in self.edges.values():
            x, y = side(e.x), side(e.y)
            pairs = [(x, y), (y, x)] if bidirectional else [(x, y)]
            for a, b in pairs:
                rows.append({"relation": e.relation, "display_relation": self.display(e.relation),
                             **{f"x_{k}": v for k, v in a.items()}, **{f"y_{k}": v for k, v in b.items()}})
        cols = ["relation", "display_relation", "x_index", "x_id", "x_type", "x_name", "x_source",
                "y_index", "y_id", "y_type", "y_name", "y_source"]
        return pd.DataFrame(rows, columns=cols)

    def _edge_facet(self, e: Edge) -> str:
        fx, fy = self.nodes[e.x].facet, self.nodes[e.y].facet
        return fx if fx == fy else f"{fx}-{fy}"

    # ---------- persistence ----------
    def save(self, directory: str | Path) -> None:
        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)
        self.nodes_df().to_csv(d / "nodes.csv", index=False)
        self.edges_df().to_csv(d / "edges.csv", index=False)

    @classmethod
    def load(cls, directory: str | Path, schema: Schema) -> KnowledgeGraph:
        d = Path(directory)
        nd = pd.read_csv(d / "nodes.csv", dtype=str, keep_default_na=False)
        ed = pd.read_csv(d / "edges.csv", dtype=str, keep_default_na=False)
        split = lambda s: set(s.split("|")) if s else set()  # noqa: E731
        nodes = {r["node_id"]: Node(r["node_id"], r["node_type"], r["node_name"], r["facet"], split(r["sources"]),
                                    split(r["xrefs"]), json.loads(r["attributes"]) if r["attributes"] else {},
                                    r["mapping_status"], float(r["confidence"])) for r in nd.to_dict("records")}
        edges = {}
        for r in ed.to_dict("records"):
            e = Edge(r["relation"], r["x_id"], r["y_id"], split(r["sources"]),
                     json.loads(r["attributes"]) if r["attributes"] else {}, float(r["confidence"]),
                     r["justification"])
            edges[e.key] = e
        return cls(schema, nodes, edges)

    def subgraph(self, node_ids: Iterable[str]) -> KnowledgeGraph:
        keep = set(node_ids)
        return KnowledgeGraph(self.schema, {k: v for k, v in self.nodes.items() if k in keep},
                              {k: e for k, e in self.edges.items() if e.x in keep and e.y in keep})
