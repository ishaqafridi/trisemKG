"""Core data structures shared by the three layers."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Code:
    """A coded value as it appears in a source: a code system plus a code."""

    system: str
    code: str
    display: str | None = None


@dataclass
class RawEntity:
    """An entity extracted by a Layer 1 adapter, before ontology mapping.

    ``local_id`` only needs to be unique within its :class:`SourceBatch`; Layer 2
    decides the global identifier from ``codes``.
    """

    local_id: str
    entity_type: str
    codes: list[Code]
    name: str | None = None
    attrs: dict[str, Any] = field(default_factory=dict)


@dataclass
class RawRelation:
    relation: str
    subject: str  # local_id of the subject RawEntity
    object: str   # local_id of the object RawEntity
    attrs: dict[str, Any] = field(default_factory=dict)


@dataclass
class SourceBatch:
    """Everything one adapter extracted from one source unit (file, bundle, table)."""

    source: str
    adapter: str
    is_knowledge: bool = False
    entities: dict[str, RawEntity] = field(default_factory=dict)
    relations: list[RawRelation] = field(default_factory=list)
    xrefs: list[tuple[str, str, str]] = field(default_factory=list)  # (subject, object, predicate) from ontologies

    def entity(self, local_id: str, entity_type: str, codes: list[Code], name: str | None = None,
               **attrs: Any) -> str:
        """Add an entity, merging codes and attributes when the local id repeats."""
        if local_id in self.entities:
            e = self.entities[local_id]
            for c in codes:
                if c not in e.codes:
                    e.codes.append(c)
            e.attrs.update({k: v for k, v in attrs.items() if v is not None})
            if name and not e.name:
                e.name = name
        else:
            self.entities[local_id] = RawEntity(local_id, entity_type, list(codes), name,
                                                {k: v for k, v in attrs.items() if v is not None})
        return local_id

    def relate(self, relation: str, subject: str, obj: str, **attrs: Any) -> None:
        self.relations.append(RawRelation(relation, subject, obj,
                                          {k: v for k, v in attrs.items() if v is not None}))


@dataclass
class MappingResult:
    """Outcome of mapping one RawEntity to a canonical identifier (an SSSOM-like record)."""

    subject_id: str
    object_id: str
    predicate_id: str
    justification: str
    confidence: float
    status: str  # canonical | mapped | lexical | hierarchical | local | unmapped


@dataclass
class Node:
    id: str
    type: str
    name: str
    facet: str
    sources: set[str] = field(default_factory=set)
    xrefs: set[str] = field(default_factory=set)
    attrs: dict[str, Any] = field(default_factory=dict)
    mapping_status: str = "canonical"
    confidence: float = 1.0


@dataclass
class Edge:
    relation: str
    x: str
    y: str
    sources: set[str] = field(default_factory=set)
    attrs: dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    justification: str = "trisem:SourceAssertion"

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.relation, self.x, self.y)
