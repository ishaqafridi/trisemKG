"""TriSemKG: a three-layer semantic framework for biomedical knowledge graph construction.

Layer 1 (``layer1_sources``)  ingests EHR/EMR, multimedia objects, multi-omics and
                              reference knowledge into source-neutral raw assertions.
Layer 2 (``layer2_semantic``) maps every entity to a canonical ontology identifier,
                              resolves duplicates and applies semantic rules.
Layer 3 (``layer3_knowledge``) assembles, validates, enriches and exports the graph.
"""
__version__ = "1.0.0"
