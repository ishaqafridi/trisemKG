"""End-to-end build: Layer 1 -> Layer 2 -> Layer 3."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .config import PipelineConfig
from .layer1_sources import load_sources
from .layer2_semantic import MappingStore, Schema, SemanticIntegrator, load_rules
from .layer3_knowledge import KnowledgeGraph, shacl_validate, validate
from .layer3_knowledge.exporters import EXPORTERS
from .layer3_knowledge.features import extract_media_features
from .layer3_knowledge.stats import compute_stats, stats_markdown
from .utils import LOG


@dataclass
class BuildResult:
    kg: KnowledgeGraph
    stats: dict
    validation: dict
    output_dir: Path


def build(config: PipelineConfig) -> BuildResult:
    t0 = time.time()
    out = config.output_dir
    out.mkdir(parents=True, exist_ok=True)
    schema = Schema.load(config.schema)

    # ---- Layer 1: ingestion ----
    LOG.info("Layer 1: ingesting %d configured sources", len(config.sources))
    for s in config.sources:
        if s.get("adapter") == "primekg":
            s.setdefault("schema", str(config.schema))
    batches = list(load_sources(config.sources))

    # ---- Layer 2: semantic integration ----
    store = MappingStore()
    n_map = store.load_dir(config.mappings_dir)
    for extra in config.semantic.get("extra_mappings", []):
        p = config.root / extra
        if p.exists():
            n_map += store.load_sssom(p)
    LOG.info("Layer 2: %d curated mappings loaded", n_map)
    integ = SemanticIntegrator(schema, store, load_rules(config.semantic.get("phenotype_rules")),
                               lexical=config.semantic.get("lexical_matching", True),
                               icd_fallback=config.semantic.get("icd_hierarchical_fallback", True),
                               min_confidence=config.semantic.get("min_confidence", 0.5))
    res = integ.integrate(batches)
    mdir = out / "mapping"
    mdir.mkdir(exist_ok=True)
    log_df = pd.DataFrame(res.mapping_log).drop_duplicates(["entity_type", "subject_id", "object_id"])
    with open(mdir / "mappings_applied.sssom.tsv", "w") as fh:
        fh.write("# mapping_set_id: https://w3id.org/trisemkg/mappings/applied\n"
                 "# comment: every mapping decision taken by Layer 2 during this build\n")
        log_df.to_csv(fh, sep="\t", index=False)
    pd.DataFrame(res.rejected, columns=["source", "relation", "x", "y", "error"]).to_csv(
        mdir / "rejected_edges.tsv", sep="\t", index=False)

    # ---- Layer 3: knowledge graph ----
    kg = KnowledgeGraph.from_integration(res, schema)
    kopt = config.knowledge
    if kopt.get("extract_media_features", True):
        extract_media_features(kg, out / "features")
    kg.save(out / "kg")
    report = validate(kg)
    exports = {}
    for name in kopt.get("exports", ["primekg"]):
        fn = EXPORTERS[name]
        target = out / ("kg" if name == "primekg" else name)
        if name == "primekg":
            exports[name] = str(fn(kg, target, kopt.get("primekg_bidirectional", True)))
        elif name == "rdf":
            exports[name] = str(fn(kg, target, kopt.get("rdf_provenance", True)))
        else:
            exports[name] = str(fn(kg, target))
    shapes = config.schema.parent / "shapes.ttl"
    ttl = out / "rdf" / "trisemkg.ttl"
    if kopt.get("shacl", True) and shapes.exists() and ttl.exists():
        report["shacl"] = shacl_validate(ttl, shapes)
    (out / "validation_report.json").write_text(json.dumps(report, indent=1, default=str))
    stats = compute_stats(kg, res.mapping_log)
    stats.update(build_seconds=round(time.time() - t0, 2), schema_version=schema.version, exports=exports)
    (out / "stats.json").write_text(json.dumps(stats, indent=1))
    (out / "stats.md").write_text(stats_markdown(stats))
    LOG.info("Layer 3: %d nodes, %d edges, validation %s, %.1fs", len(kg.nodes), len(kg.edges),
             "passed" if report["passed"] else "FAILED", stats["build_seconds"])
    return BuildResult(kg, stats, report, out)
