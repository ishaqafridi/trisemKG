"""Small shared helpers."""
from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path

LOG = logging.getLogger("trisemkg")


def setup_logging(verbose: bool = False) -> None:
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


_ws = re.compile(r"[^a-z0-9]+")


def norm_label(text: str) -> str:
    """Normalise a label for lexical matching: lowercase, alphanumerics only."""
    return _ws.sub(" ", text.lower()).strip()


def slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-")
