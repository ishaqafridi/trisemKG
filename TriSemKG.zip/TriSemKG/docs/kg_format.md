# Knowledge graph format

## `kg/kg.csv` (PrimeKG layout)

| Column | Meaning |
| --- | --- |
| relation | schema relation name (PrimeKG names kept verbatim) |
| display_relation | human-readable label |
| x_index, y_index | integer node indices, stable within a build |
| x_id, y_id | local part of the CURIE (e.g. `0007254`, `672`, `patient-MRN00004`) |
| x_type, y_type | node type |
| x_name, y_name | label |
| x_source, y_source | CURIE prefix (MONDO, NCBIGene, DRUGBANK, TRISEM …) |

With `primekg_bidirectional: true` each edge appears in both directions, as in PrimeKG.

## `kg/nodes.csv`

`node_index, node_id (CURIE), node_type, node_name, node_source, facet, mapping_status, confidence, xrefs, sources, attributes (JSON)`

Media objects carry `uri`, `mime_type`, `modality`, `sha256`, `size_bytes` and content descriptors (`width`, `height`, `frames`, `duration_s`, `n_words`, `feature_set`).

## `kg/edges.csv`

`relation, display_relation, x_index, x_id, y_index, y_id, facet, confidence, justification, sources, attributes (JSON)`

Measurement edges carry `n_obs, value_mean, value_last, value_min, value_max, unit`; variant edges carry `genotype, vaf`; expression edges carry `value, zscore, direction`.

## Node identifiers

| Type | Pattern |
| --- | --- |
| patient | `TRISEM:patient-<MRN>` |
| encounter | `TRISEM:encounter-<source>-<id>` |
| imaging_study | `TRISEM:study-<StudyInstanceUID>` |
| media_object | `TRISEM:media-<SOPInstanceUID or media_id>` |
| biosample | `TRISEM:sample-<sample_id>` |
| variant | `TRISEM:variant-<genome>-<chrom>-<pos>-<ref>-<alt>` |
| knowledge and clinical concepts | canonical ontology CURIE |

`TRISEM:` expands to `https://w3id.org/trisemkg/resource/`; register the w3id redirect or change the prefix in the schema before publishing RDF.
