# Architecture

TriSemKG separates **what a source says** (Layer 1), **what it means** (Layer 2) and **what the graph is used for** (Layer 3). Each layer has one contract with the next, so a new source, terminology or export can be added without touching the other two.

## Layer 1: data source and ingestion

Contract: every adapter yields `SourceBatch` objects containing `RawEntity` (local id, schema node type, list of `Code(system, code, display)`, attributes) and `RawRelation` (schema relation, subject and object local ids, attributes).

Adapters never translate codes. A FHIR Condition coded in ICD-10-CM and SNOMED CT is emitted with both codings; choosing MONDO happens in Layer 2, where it is logged.

| Adapter | Input | Entities emitted |
| --- | --- | --- |
| `fhir` | FHIR R4 Bundle JSON or NDJSON | patient, encounter, disease, drug, lab_test (with values), procedure, imaging_study, media_object |
| `omop` | OMOP CDM v5 CSV tables + CONCEPT | patient, encounter, disease, drug, lab_test, procedure |
| `dicom` | DICOM files (header only) | media_object, imaging_study, patient, anatomy |
| `media_manifest` | CSV listing any media file | media_object (+ checksum), imaging_study, anatomy, disease, derived-from links |
| `sample_sheet` | TSV | biosample, patient, anatomy |
| `vcf` | multi-sample VCF | variant, gene/protein, biosample |
| `expression`, `proteomics`, `methylation` | feature × sample matrices | biosample, gene/protein (thresholded edges) |
| `seed_knowledge`, `obo`, `primekg` | curated TSV, OBO ontologies, PrimeKG kg.csv | knowledge-facet nodes and relations, ontology cross-references |

## Layer 2: semantic integration

1. **Normalisation**: source code systems (FHIR URIs, OMOP vocabulary ids, aliases) become CURIE prefixes (`curie.py`).
2. **Mapping**: `OntologyMapper` picks one canonical identifier per entity using the schema's canonical namespace for that type (`mapper.py`, see `ontology_mapping.md`).
3. **Entity resolution**: entities that map to the same identifier become one node; their source codes become `xrefs` and their sources accumulate (`integrator.py`). Patients from FHIR, OMOP, DICOM and the media manifest merge on MRN.
4. **Edge translation**: relations are re-pointed to canonical nodes and checked against the schema's domain and range; violations are rejected and logged.
5. **Rules**: numeric measurements are summarised (count, mean, last, min, max) and phenotype rules add `patient_phenotype` edges.

## Layer 3: knowledge graph and application

* `graph.py` holds the graph, assigns stable integer indices (facet, type, id order) and produces the PrimeKG-layout table.
* `validate.py` checks dangling edges, domain/range, canonical namespaces, required attributes (for media: uri, mime_type, modality, sha256), isolated nodes and possible duplicates; the RDF export is checked with SHACL shapes.
* `features.py` computes content features for media objects.
* `exporters.py` writes PrimeKG CSV, Neo4j import files, RDF with reified provenance, GraphML and NumPy edge-index tensors.
* `query.py` implements drug-candidate ranking, patient similarity, multimedia evidence retrieval and patient summaries.

## Provenance model

Every node keeps the set of source units it came from; every edge keeps its sources, a confidence (the minimum confidence of its two end-point mappings, or the rule confidence) and a justification (`trisem:SourceAssertion`, `trisem:RuleDerived`). The RDF export reifies each edge with `prov:wasDerivedFrom`, `tsv:confidence` and `tsv:justification`.
