# Ontology mapping

## Canonical namespaces

| Node type | Canonical | Also accepted |
| --- | --- | --- |
| disease | MONDO | ICD10CM, SNOMEDCT, DOID |
| drug | DRUGBANK | RXNORM, CHEBI |
| gene/protein | NCBIGene | HGNC, ENSEMBL, UniProtKB, HGNC symbols |
| effect/phenotype | HP | SNOMEDCT |
| anatomy | UBERON | SNOMEDCT, DICOM body part |
| lab_test | LOINC | |
| procedure | SNOMEDCT | |
| biological_process, molecular_function, cellular_component | GO | |
| pathway | REACT | |
| exposure | MESH | |

MONDO, NCBI Gene, DrugBank, HPO, GO and UBERON match PrimeKG's choices, so a PrimeKG backbone and patient data meet on the same identifiers.

## Mapping strategy

For each entity Layer 2 tries, in order: local identity → canonical code → curated or cross-reference mapping → ICD-10-CM hierarchical fallback → lexical match → unmapped. The first success wins; all outcomes are written to `output/mapping/mappings_applied.sssom.tsv` with `predicate_id`, `mapping_justification`, `confidence` and `status`.

* **Curated mappings** are SSSOM TSV files in `mappings/`. Add the Mondo SSSOM release (`trisemkg download mondo_sssom`) through `semantic.extra_mappings` for broad ICD-10-CM, DOID and OMIM coverage.
* **Cross-references** from OBO `xref` lines (for example MONDO → ICD10CM) are added automatically with confidence 0.9.
* **Hierarchical fallback** truncates ICD-10-CM codes one character at a time (C50.911 → C50.91 → C50.9 → C50) and records the result as `skos:broadMatch` with 0.85 × the parent mapping's confidence.
* **Lexical matching** compares normalised names, displays and gene symbols against labels and synonyms of canonical-namespace nodes loaded from knowledge sources; it accepts only unambiguous single hits.
* **Unmapped** entities keep their best accepted source identifier and `mapping_status = unmapped`, so nothing is silently dropped and coverage can be reported.

## Confidence propagation

Edge confidence = min(confidence of subject mapping, confidence of object mapping). Edges below 0.6 are listed in the validation report under `low_confidence_edges`.

## Semantic rules

`configs/phenotype_rules.yaml` maps measurement thresholds to HPO terms, applied to the mean of each patient's observations:

| Rule | Condition | Phenotype |
| --- | --- | --- |
| R1 | HbA1c (LOINC 4548-4) ≥ 6.5 % | HP:0003074 Hyperglycemia |
| R2 | Glucose (LOINC 2345-7) ≥ 126 mg/dL | HP:0003074 Hyperglycemia |
| R3 | Systolic BP (LOINC 8480-6) ≥ 140 mm[Hg] | HP:0000822 Hypertension |
| R4 | BMI (LOINC 39156-5) ≥ 30 kg/m² | HP:0001513 Obesity |
| R5 | Creatinine (LOINC 2160-0) > 1.3 mg/dL | HP:0003259 Elevated circulating creatinine concentration |

Thresholds are common clinical cut-offs supplied as defaults; review them for your population and units.

## Evaluating mapping quality

`output/stats.md` reports, per entity type, the number of distinct source codes and how many were resolved at each step. For a manuscript, compare `mappings_applied.sssom.tsv` against a manually curated gold standard to report precision and recall per step.
