# Data sources

## Bundled synthetic cohort

`trisemkg synth --patients N --seed S` writes:

| Path | Content |
| --- | --- |
| `ehr/fhir/bundle_<MRN>.json` | FHIR R4 collection bundles: Patient, Encounter, Condition (ICD-10-CM + SNOMED CT), MedicationRequest (RxNorm), Observation (LOINC with UCUM units), Procedure, ImagingStudy |
| `ehr/omop/*.csv` | OMOP CDM PERSON, VISIT_OCCURRENCE, CONDITION_OCCURRENCE, DRUG_EXPOSURE, MEASUREMENT, CONCEPT; about 15% of patients also appear in FHIR |
| `multimedia/dicom/*.dcm` | Digital mammography (MG), four views per breast-cancer patient, 12-bit, 128×128 |
| `multimedia/files/` | H&E slide thumbnails and derived tiles (PNG), breast ultrasound cine loops (GIF), radiologist dictations (WAV), pathology reports (TXT), chest radiographs (PNG) |
| `multimedia/media_manifest.csv` | One row per non-DICOM media object |
| `omics/sample_sheet.tsv` | Tumour biosamples linked to MRNs |
| `omics/somatic_variants.vcf` | Multi-sample VCF (GRCh38) with GENE and CLNSIG annotations |
| `omics/rnaseq_tpm.tsv`, `proteomics_log2.tsv`, `methylation_beta.tsv` | Feature × sample matrices |
| `cohort_truth.csv` | Ground truth for tests (diagnoses, receptor status, carriers, source membership) |

The cohort models breast cancer (receptor subtypes, BRCA carriers), type 2 diabetes and hypertension so that the graph exercises oncology, cardiometabolic and pharmacogenomic paths.

## Public reference sources

| Source | Command | Licence notes |
| --- | --- | --- |
| PrimeKG kg.csv | `trisemkg download primekg` | CC BY 4.0; inherits terms of its 20 sources |
| MONDO | `trisemkg download mondo` | CC BY 4.0 |
| Mondo SSSOM mappings | `trisemkg download mondo_sssom` | CC BY 4.0 |
| HPO | `trisemkg download hpo` | HPO licence (free, attribution) |
| GO | `trisemkg download go` | CC BY 4.0 |
| UBERON | `trisemkg download uberon` | CC BY 3.0 |

Download URLs are in `src/trisemkg/layer1_sources/download.py`; confirm them on each provider's site.

## Real clinical data

* De-identify before ingestion (HIPAA Safe Harbor or an equivalent standard) and keep the MRN-to-pseudonym key outside the graph.
* Remove burned-in annotations and identifying DICOM tags; the DICOM adapter never reads pixel data, but the feature extractor does.
* Obtain ethics approval for linking EHR, imaging and genomic data.
* MIMIC-IV (FHIR or OMOP versions) and the TCGA/TCIA breast cancer collections are suitable public test beds after their data-use agreements.
